import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { insertProjectSchema, insertBuildSchema, insertDeploymentSchema, insertTeamSchema } from "@shared/schema";
import { githubWebhookHandler } from "./services/github";
import { gitlabWebhookHandler } from "./services/gitlab";
import { bitbucketWebhookHandler } from "./services/bitbucket";
import { autoBuildAgent, deployMasterAgent, secureGuardAgent, costOptimizerAgent } from "./services/agents";
import { complianceService } from "./services/compliance";
import { setupWebSocket } from "./services/websocket";
import crypto from "crypto";

export async function registerRoutes(app: Express): Promise<Server> {
  // Dashboard stats
  app.get("/api/stats", async (req, res) => {
    try {
      const projectStats = await storage.getProjectStats();
      const securityStats = await storage.getSecurityStats();
      const costStats = await storage.getCostStats();
      
      res.json({
        projectStats,
        securityStats,
        costStats
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  // Projects
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch projects" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getProject(parseInt(req.params.id));
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch project" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const projectData = insertProjectSchema.parse(req.body);
      
      // Generate webhook secret
      const webhookSecret = crypto.randomBytes(32).toString('hex');
      
      const project = await storage.createProject({
        ...projectData,
        webhookSecret
      });
      
      res.status(201).json(project);
    } catch (error) {
      res.status(400).json({ error: "Invalid project data" });
    }
  });

  app.put("/api/projects/:id", async (req, res) => {
    try {
      const projectData = insertProjectSchema.partial().parse(req.body);
      const project = await storage.updateProject(parseInt(req.params.id), projectData);
      res.json(project);
    } catch (error) {
      res.status(400).json({ error: "Invalid project data" });
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      await storage.deleteProject(parseInt(req.params.id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete project" });
    }
  });

  // Builds
  app.get("/api/builds", async (req, res) => {
    try {
      const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const builds = await storage.getBuilds(projectId, limit);
      res.json(builds);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch builds" });
    }
  });

  app.get("/api/builds/:id", async (req, res) => {
    try {
      const build = await storage.getBuild(parseInt(req.params.id));
      if (!build) {
        return res.status(404).json({ error: "Build not found" });
      }
      res.json(build);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch build" });
    }
  });

  app.get("/api/builds/recent/:limit", async (req, res) => {
    try {
      const limit = parseInt(req.params.limit);
      const builds = await storage.getRecentBuilds(limit);
      res.json(builds);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch recent builds" });
    }
  });

  // Deployments
  app.get("/api/deployments", async (req, res) => {
    try {
      const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const deployments = await storage.getDeployments(projectId, limit);
      res.json(deployments);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch deployments" });
    }
  });

  // Agents
  app.get("/api/agents", async (req, res) => {
    try {
      const agents = await storage.getAgents();
      res.json(agents);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch agents" });
    }
  });

  app.post("/api/agents/:id/heartbeat", async (req, res) => {
    try {
      await storage.updateAgentHeartbeat(parseInt(req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update agent heartbeat" });
    }
  });

  // Notifications
  app.get("/api/notifications", async (req, res) => {
    try {
      const isRead = req.query.isRead === 'true' ? true : req.query.isRead === 'false' ? false : undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const notifications = await storage.getNotifications(isRead, limit);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch notifications" });
    }
  });

  app.post("/api/notifications/:id/read", async (req, res) => {
    try {
      await storage.markNotificationAsRead(parseInt(req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to mark notification as read" });
    }
  });

  // Webhooks
  app.post("/api/webhooks/github", githubWebhookHandler);
  app.post("/api/webhooks/gitlab/:projectId", gitlabWebhookHandler);
  app.post("/api/webhooks/bitbucket/:projectId", bitbucketWebhookHandler);

  // Teams
  app.get("/api/teams", async (req, res) => {
    try {
      const teams = await storage.getTeams();
      res.json(teams);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch teams" });
    }
  });

  app.post("/api/teams", async (req, res) => {
    try {
      const teamData = insertTeamSchema.parse(req.body);
      const team = await storage.createTeam(teamData);
      res.json(team);
    } catch (error) {
      res.status(400).json({ error: "Invalid team data" });
    }
  });

  app.put("/api/teams/:id", async (req, res) => {
    try {
      const teamData = insertTeamSchema.partial().parse(req.body);
      const team = await storage.updateTeam(parseInt(req.params.id), teamData);
      res.json(team);
    } catch (error) {
      res.status(400).json({ error: "Invalid team data" });
    }
  });

  app.delete("/api/teams/:id", async (req, res) => {
    try {
      await storage.deleteTeam(parseInt(req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete team" });
    }
  });

  // Compliance Reports
  app.get("/api/compliance", async (req, res) => {
    try {
      const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const reports = await storage.getComplianceReports(projectId, limit);
      res.json(reports);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch compliance reports" });
    }
  });

  app.post("/api/compliance/:projectId/run", async (req, res) => {
    try {
      const project = await storage.getProject(parseInt(req.params.projectId));
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      
      const result = await complianceService.runComplianceCheck(project);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to run compliance check" });
    }
  });

  // Performance Metrics
  app.get("/api/metrics/:projectId", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const metrics = await storage.getPerformanceMetrics(projectId, limit);
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch performance metrics" });
    }
  });

  // Audit Logs
  app.get("/api/audit", async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const logs = await storage.getAuditLogs(userId, projectId, limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch audit logs" });
    }
  });

  // Trigger build manually
  app.post("/api/projects/:id/build", async (req, res) => {
    try {
      const project = await storage.getProject(parseInt(req.params.id));
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }

      // Trigger AutoBuild Agent
      const buildId = await autoBuildAgent.triggerBuild(project, {
        commitHash: req.body.commitHash || 'manual',
        branch: req.body.branch || project.branch
      });

      res.json({ buildId, message: "Build triggered successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to trigger build" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  // Setup WebSocket
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  setupWebSocket(wss);

  // Initialize agents
  await initializeAgents();

  return httpServer;
}

async function initializeAgents() {
  // Create or update agent records
  const agentConfigs = [
    { name: "AutoBuild Agent", type: "autobuild", configuration: { maxConcurrentBuilds: 5 } },
    { name: "DeployMaster Agent", type: "deploymaster", configuration: { maxConcurrentDeployments: 3 } },
    { name: "SecureGuard Agent", type: "secureguard", configuration: { scanTimeout: 300 } },
    { name: "CostOptimizer Agent", type: "costoptimizer", configuration: { analysisInterval: 3600 } }
  ];

  for (const config of agentConfigs) {
    try {
      await storage.createAgent(config);
    } catch (error) {
      // Agent might already exist, that's okay
    }
  }

  // Start agent heartbeats
  setInterval(async () => {
    const agents = await storage.getAgents();
    for (const agent of agents) {
      await storage.updateAgentHeartbeat(agent.id);
    }
  }, 30000); // Every 30 seconds
}
