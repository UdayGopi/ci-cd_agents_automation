import { 
  ECSClient, 
  UpdateServiceCommand, 
  RegisterTaskDefinitionCommand,
  DescribeServicesCommand 
} from "@aws-sdk/client-ecs";
import { 
  EKSClient, 
  DescribeClusterCommand 
} from "@aws-sdk/client-eks";
import { 
  ECRClient, 
  GetAuthorizationTokenCommand,
  CreateRepositoryCommand 
} from "@aws-sdk/client-ecr";
import { 
  CostExplorerClient, 
  GetCostAndUsageCommand 
} from "@aws-sdk/client-cost-explorer";

export class AWSService {
  private ecsClient: ECSClient;
  private eksClient: EKSClient;
  private ecrClient: ECRClient;
  private costExplorerClient: CostExplorerClient;

  constructor() {
    const region = process.env.AWS_REGION || 'us-east-1';
    const config = {
      region,
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || '',
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || ''
      }
    };

    this.ecsClient = new ECSClient(config);
    this.eksClient = new EKSClient(config);
    this.ecrClient = new ECRClient(config);
    this.costExplorerClient = new CostExplorerClient(config);
  }

  async deployToECS(params: {
    clusterName: string;
    serviceName: string;
    dockerImageUrl: string;
    environmentVariables?: Record<string, string>;
  }) {
    try {
      // Get current task definition
      const describeServices = await this.ecsClient.send(
        new DescribeServicesCommand({
          cluster: params.clusterName,
          services: [params.serviceName]
        })
      );

      const service = describeServices.services?.[0];
      if (!service) {
        throw new Error(`Service ${params.serviceName} not found in cluster ${params.clusterName}`);
      }

      // Create new task definition with updated image
      const taskDefinition = service.taskDefinition;
      // In a real implementation, you would fetch the existing task definition
      // and update it with the new image URL
      
      const newTaskDef = await this.ecsClient.send(
        new RegisterTaskDefinitionCommand({
          family: params.serviceName,
          taskRoleArn: service.taskDefinition,
          containerDefinitions: [
            {
              name: params.serviceName,
              image: params.dockerImageUrl,
              memory: 512,
              cpu: 256,
              essential: true,
              portMappings: [
                {
                  containerPort: 8000,
                  protocol: 'tcp'
                }
              ],
              environment: Object.entries(params.environmentVariables || {}).map(([name, value]) => ({
                name,
                value
              }))
            }
          ]
        })
      );

      // Update service with new task definition
      await this.ecsClient.send(
        new UpdateServiceCommand({
          cluster: params.clusterName,
          service: params.serviceName,
          taskDefinition: newTaskDef.taskDefinition?.taskDefinitionArn,
          forceNewDeployment: true
        })
      );

      return {
        success: true,
        taskDefinitionArn: newTaskDef.taskDefinition?.taskDefinitionArn
      };
    } catch (error) {
      console.error('ECS deployment error:', error);
      throw error;
    }
  }

  async deployToEKS(params: {
    clusterName: string;
    serviceName: string;
    dockerImageUrl: string;
    environmentVariables?: Record<string, string>;
  }) {
    try {
      // In a real implementation, you would use kubectl or the Kubernetes client
      // to update the deployment with the new image
      
      // For now, we'll simulate the deployment
      console.log(`Deploying ${params.dockerImageUrl} to EKS cluster ${params.clusterName}`);
      
      return {
        success: true,
        deploymentName: params.serviceName
      };
    } catch (error) {
      console.error('EKS deployment error:', error);
      throw error;
    }
  }

  async pushToECR(params: {
    repositoryName: string;
    imageTag: string;
    dockerImageData: Buffer;
  }) {
    try {
      // Get ECR authorization token
      const authToken = await this.ecrClient.send(
        new GetAuthorizationTokenCommand({})
      );

      const token = authToken.authorizationData?.[0]?.authorizationToken;
      if (!token) {
        throw new Error('Failed to get ECR authorization token');
      }

      // Create repository if it doesn't exist
      try {
        await this.ecrClient.send(
          new CreateRepositoryCommand({
            repositoryName: params.repositoryName
          })
        );
      } catch (error) {
        // Repository might already exist
      }

      // In a real implementation, you would use Docker to push the image
      // For now, we'll return a simulated ECR URL
      const ecrUrl = `123456789012.dkr.ecr.us-east-1.amazonaws.com/${params.repositoryName}:${params.imageTag}`;
      
      return {
        success: true,
        imageUrl: ecrUrl
      };
    } catch (error) {
      console.error('ECR push error:', error);
      throw error;
    }
  }

  async getCostAndUsage(startDate: string, endDate: string) {
    try {
      const response = await this.costExplorerClient.send(
        new GetCostAndUsageCommand({
          TimePeriod: {
            Start: startDate,
            End: endDate
          },
          Granularity: 'MONTHLY',
          Metrics: ['BlendedCost', 'UnblendedCost', 'UsageQuantity']
        })
      );

      return response.ResultsByTime;
    } catch (error) {
      console.error('Cost Explorer error:', error);
      throw error;
    }
  }

  async performHealthCheck(url: string): Promise<boolean> {
    try {
      const response = await fetch(url, { 
        method: 'GET',
        timeout: 30000 
      });
      return response.ok;
    } catch (error) {
      console.error('Health check failed:', error);
      return false;
    }
  }
}

export const awsService = new AWSService();
