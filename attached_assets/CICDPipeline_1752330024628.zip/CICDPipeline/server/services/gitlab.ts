import { Request, Response } from "express";
import { storage } from "../storage";
import { autoBuildAgent } from "./agents";
import crypto from "crypto";

export async function gitlabWebhookHandler(req: Request, res: Response) {
  try {
    const payload = req.body;
    const signature = req.headers["x-gitlab-token"] as string;
    
    // Find project by webhook secret
    const projects = await storage.getProjects();
    const project = projects.find(p => p.webhookSecret === signature);
    
    if (!project) {
      return res.status(404).json({ error: "Project not found" });
    }

    // Handle different GitLab events
    switch (req.headers["x-gitlab-event"]) {
      case "Push Hook":
        await handlePushEvent(payload, project);
        break;
      case "Merge Request Hook":
        await handleMergeRequestEvent(payload, project);
        break;
      case "Tag Push Hook":
        await handleTagPushEvent(payload, project);
        break;
      default:
        console.log("Unhandled GitLab event:", req.headers["x-gitlab-event"]);
    }

    res.status(200).json({ message: "Webhook processed successfully" });
  } catch (error) {
    console.error("GitLab webhook error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
}

async function handlePushEvent(payload: any, project: any) {
  const { commits, ref, repository } = payload;
  
  if (commits && commits.length > 0) {
    const latestCommit = commits[commits.length - 1];
    const branch = ref.replace("refs/heads/", "");
    
    // Only trigger build for the configured branch
    if (branch === project.branch) {
      await autoBuildAgent.triggerBuild(project, {
        commitHash: latestCommit.id,
        branch: branch,
        commitMessage: latestCommit.message,
        author: latestCommit.author.name,
        repositoryUrl: repository.git_http_url,
      });
    }
  }
}

async function handleMergeRequestEvent(payload: any, project: any) {
  const { object_attributes, merge_request } = payload;
  
  if (object_attributes.action === "opened" || object_attributes.action === "update") {
    // Trigger build for merge request
    await autoBuildAgent.triggerBuild(project, {
      commitHash: object_attributes.last_commit.id,
      branch: object_attributes.source_branch,
      commitMessage: `MR: ${object_attributes.title}`,
      author: object_attributes.author.name,
      repositoryUrl: merge_request.source.git_http_url,
      isPullRequest: true,
    });
  }
}

async function handleTagPushEvent(payload: any, project: any) {
  const { ref, commits, repository } = payload;
  
  if (commits && commits.length > 0) {
    const latestCommit = commits[commits.length - 1];
    const tag = ref.replace("refs/tags/", "");
    
    // Trigger build for tag
    await autoBuildAgent.triggerBuild(project, {
      commitHash: latestCommit.id,
      branch: tag,
      commitMessage: `Tag: ${tag}`,
      author: latestCommit.author.name,
      repositoryUrl: repository.git_http_url,
      isTag: true,
    });
  }
}

export function generateGitLabWebhookUrl(projectId: number): string {
  const baseUrl = process.env.WEBHOOK_BASE_URL || "https://your-domain.com";
  return `${baseUrl}/api/webhooks/gitlab/${projectId}`;
}

export class GitLabService {
  private apiUrl: string;
  private accessToken: string;

  constructor(apiUrl: string = "https://gitlab.com/api/v4", accessToken?: string) {
    this.apiUrl = apiUrl;
    this.accessToken = accessToken || "";
  }

  async getProject(projectId: string) {
    const response = await fetch(`${this.apiUrl}/projects/${projectId}`, {
      headers: {
        "Authorization": `Bearer ${this.accessToken}`,
      },
    });
    return response.json();
  }

  async getCommits(projectId: string, branch: string) {
    const response = await fetch(`${this.apiUrl}/projects/${projectId}/repository/commits?ref_name=${branch}`, {
      headers: {
        "Authorization": `Bearer ${this.accessToken}`,
      },
    });
    return response.json();
  }

  async createWebhook(projectId: string, webhookUrl: string, secretToken: string) {
    const response = await fetch(`${this.apiUrl}/projects/${projectId}/hooks`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${this.accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        url: webhookUrl,
        token: secretToken,
        push_events: true,
        merge_requests_events: true,
        tag_push_events: true,
      }),
    });
    return response.json();
  }
}

export const gitlabService = new GitLabService();