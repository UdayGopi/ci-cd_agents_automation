import { Request, Response } from "express";
import { storage } from "../storage";
import { autoBuildAgent } from "./agents";
import crypto from "crypto";

export async function bitbucketWebhookHandler(req: Request, res: Response) {
  try {
    const payload = req.body;
    const signature = req.headers["x-hub-signature-256"] as string;
    
    // Find project by webhook secret
    const projects = await storage.getProjects();
    const project = projects.find(p => p.webhookSecret && verifyBitbucketWebhook(JSON.stringify(payload), signature, p.webhookSecret));
    
    if (!project) {
      return res.status(404).json({ error: "Project not found" });
    }

    // Handle different Bitbucket events
    const eventType = req.headers["x-event-key"] as string;
    
    switch (eventType) {
      case "repo:push":
        await handlePushEvent(payload, project);
        break;
      case "pullrequest:created":
      case "pullrequest:updated":
        await handlePullRequestEvent(payload, project);
        break;
      default:
        console.log("Unhandled Bitbucket event:", eventType);
    }

    res.status(200).json({ message: "Webhook processed successfully" });
  } catch (error) {
    console.error("Bitbucket webhook error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
}

function verifyBitbucketWebhook(payload: string, signature: string, secret: string): boolean {
  if (!signature || !secret) return false;
  
  const hmac = crypto.createHmac("sha256", secret);
  hmac.update(payload);
  const computedSignature = "sha256=" + hmac.digest("hex");
  
  return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(computedSignature));
}

async function handlePushEvent(payload: any, project: any) {
  const { push } = payload;
  
  if (push && push.changes && push.changes.length > 0) {
    const change = push.changes[0];
    const { new: newCommit } = change;
    
    if (newCommit && newCommit.name === project.branch) {
      await autoBuildAgent.triggerBuild(project, {
        commitHash: newCommit.target.hash,
        branch: newCommit.name,
        commitMessage: newCommit.target.message,
        author: newCommit.target.author.display_name,
        repositoryUrl: payload.repository.links.clone.find((link: any) => link.name === "https").href,
      });
    }
  }
}

async function handlePullRequestEvent(payload: any, project: any) {
  const { pullrequest } = payload;
  
  if (pullrequest) {
    await autoBuildAgent.triggerBuild(project, {
      commitHash: pullrequest.source.commit.hash,
      branch: pullrequest.source.branch.name,
      commitMessage: `PR: ${pullrequest.title}`,
      author: pullrequest.author.display_name,
      repositoryUrl: pullrequest.source.repository.links.clone.find((link: any) => link.name === "https").href,
      isPullRequest: true,
    });
  }
}

export function generateBitbucketWebhookUrl(projectId: number): string {
  const baseUrl = process.env.WEBHOOK_BASE_URL || "https://your-domain.com";
  return `${baseUrl}/api/webhooks/bitbucket/${projectId}`;
}

export class BitbucketService {
  private apiUrl: string;
  private accessToken: string;

  constructor(apiUrl: string = "https://api.bitbucket.org/2.0", accessToken?: string) {
    this.apiUrl = apiUrl;
    this.accessToken = accessToken || "";
  }

  async getRepository(workspace: string, repoSlug: string) {
    const response = await fetch(`${this.apiUrl}/repositories/${workspace}/${repoSlug}`, {
      headers: {
        "Authorization": `Bearer ${this.accessToken}`,
      },
    });
    return response.json();
  }

  async getCommits(workspace: string, repoSlug: string, branch: string) {
    const response = await fetch(`${this.apiUrl}/repositories/${workspace}/${repoSlug}/commits/${branch}`, {
      headers: {
        "Authorization": `Bearer ${this.accessToken}`,
      },
    });
    return response.json();
  }

  async createWebhook(workspace: string, repoSlug: string, webhookUrl: string, secretToken: string) {
    const response = await fetch(`${this.apiUrl}/repositories/${workspace}/${repoSlug}/hooks`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${this.accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        description: "PipelineForge CI/CD Webhook",
        url: webhookUrl,
        active: true,
        secret: secretToken,
        events: [
          "repo:push",
          "pullrequest:created",
          "pullrequest:updated",
        ],
      }),
    });
    return response.json();
  }
}

export const bitbucketService = new BitbucketService();