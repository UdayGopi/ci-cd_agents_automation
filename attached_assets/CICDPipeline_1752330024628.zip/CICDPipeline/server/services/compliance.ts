import { storage } from "../storage";
import { Project, Build, InsertComplianceReport, InsertAuditLog } from "@shared/schema";
import { securityService } from "./security";

export class ComplianceService {
  async runComplianceCheck(project: Project, build?: Build) {
    try {
      const reports = await Promise.all([
        this.runSecurityCompliance(project, build),
        this.runQualityCompliance(project, build),
        this.runDataCompliance(project, build),
        this.runAccessControlCompliance(project),
      ]);
      
      const overallStatus = this.calculateOverallStatus(reports);
      
      // Store compliance report
      const complianceReport = await storage.createComplianceReport({
        projectId: project.id,
        reportType: "comprehensive",
        status: overallStatus,
        findings: reports,
        recommendations: this.generateRecommendations(reports),
        validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
      });
      
      return {
        reportId: complianceReport.id,
        status: overallStatus,
        findings: reports,
        recommendations: complianceReport.recommendations,
      };
    } catch (error) {
      console.error("Compliance check failed:", error);
      return null;
    }
  }

  private async runSecurityCompliance(project: Project, build?: Build) {
    const findings = [];
    
    // Security scan results
    if (build?.securityScanResults) {
      const scanResults = typeof build.securityScanResults === 'string' 
        ? JSON.parse(build.securityScanResults) 
        : build.securityScanResults;
      
      if (scanResults.vulnerabilities?.length > 0) {
        const criticalVulns = scanResults.vulnerabilities.filter(v => v.severity === "critical");
        const highVulns = scanResults.vulnerabilities.filter(v => v.severity === "high");
        
        if (criticalVulns.length > 0) {
          findings.push({
            type: "security",
            severity: "critical",
            title: "Critical Security Vulnerabilities",
            description: `Found ${criticalVulns.length} critical vulnerabilities`,
            details: criticalVulns,
            compliant: false,
          });
        }
        
        if (highVulns.length > 0) {
          findings.push({
            type: "security",
            severity: "high",
            title: "High-Risk Security Vulnerabilities",
            description: `Found ${highVulns.length} high-risk vulnerabilities`,
            details: highVulns,
            compliant: false,
          });
        }
      }
    }
    
    // Check for security best practices
    const securityChecks = await this.checkSecurityBestPractices(project);
    findings.push(...securityChecks);
    
    return {
      category: "security",
      status: findings.some(f => !f.compliant) ? "non-compliant" : "compliant",
      findings,
    };
  }

  private async runQualityCompliance(project: Project, build?: Build) {
    const findings = [];
    
    // Test coverage check
    if (build?.testResults) {
      const testResults = typeof build.testResults === 'string' 
        ? JSON.parse(build.testResults) 
        : build.testResults;
      
      const coverage = testResults.coverage || 0;
      const minimumCoverage = 80;
      
      if (coverage < minimumCoverage) {
        findings.push({
          type: "quality",
          severity: "medium",
          title: "Insufficient Test Coverage",
          description: `Test coverage is ${coverage}%, below minimum requirement of ${minimumCoverage}%`,
          compliant: false,
        });
      }
    }
    
    // Build quality checks
    if (build?.buildLogs) {
      const qualityChecks = this.analyzeCodeQuality(build.buildLogs);
      findings.push(...qualityChecks);
    }
    
    return {
      category: "quality",
      status: findings.some(f => !f.compliant) ? "non-compliant" : "compliant",
      findings,
    };
  }

  private async runDataCompliance(project: Project, build?: Build) {
    const findings = [];
    
    // Check for data protection compliance
    const dataChecks = [
      this.checkDataEncryption(project),
      this.checkDataRetention(project),
      this.checkDataAccess(project),
    ];
    
    findings.push(...dataChecks);
    
    return {
      category: "data",
      status: findings.some(f => !f.compliant) ? "non-compliant" : "compliant",
      findings,
    };
  }

  private async runAccessControlCompliance(project: Project) {
    const findings = [];
    
    // Check access control settings
    const accessChecks = [
      this.checkRoleBasedAccess(project),
      this.checkPrincipleOfLeastPrivilege(project),
      this.checkAuthenticationMethods(project),
    ];
    
    findings.push(...accessChecks);
    
    return {
      category: "access_control",
      status: findings.some(f => !f.compliant) ? "non-compliant" : "compliant",
      findings,
    };
  }

  private async checkSecurityBestPractices(project: Project) {
    const findings = [];
    
    // Check for secrets in environment variables
    if (project.environmentVariables) {
      const envVars = typeof project.environmentVariables === 'string' 
        ? JSON.parse(project.environmentVariables) 
        : project.environmentVariables;
      
      const suspiciousKeys = ['password', 'secret', 'key', 'token', 'api_key'];
      const foundSecrets = Object.keys(envVars || {}).filter(key => 
        suspiciousKeys.some(suspicious => key.toLowerCase().includes(suspicious))
      );
      
      if (foundSecrets.length > 0) {
        findings.push({
          type: "security",
          severity: "medium",
          title: "Potential Secrets in Environment Variables",
          description: `Found potentially sensitive keys: ${foundSecrets.join(', ')}`,
          compliant: false,
        });
      }
    }
    
    // Check deployment target security
    if (project.deploymentTarget === "ecs" || project.deploymentTarget === "eks") {
      findings.push({
        type: "security",
        severity: "low",
        title: "Container Security Best Practices",
        description: "Ensure container images are regularly updated and scanned",
        compliant: true,
      });
    }
    
    return findings;
  }

  private analyzeCodeQuality(buildLogs: string) {
    const findings = [];
    
    // Check for linting issues
    if (buildLogs.includes("ESLint") || buildLogs.includes("pylint")) {
      const lintingPassed = !buildLogs.includes("error") && !buildLogs.includes("failed");
      
      if (!lintingPassed) {
        findings.push({
          type: "quality",
          severity: "medium",
          title: "Code Quality Issues",
          description: "Linting checks failed, code quality issues detected",
          compliant: false,
        });
      }
    }
    
    // Check for build warnings
    const warningCount = (buildLogs.match(/warning/gi) || []).length;
    if (warningCount > 10) {
      findings.push({
        type: "quality",
        severity: "low",
        title: "Build Warnings",
        description: `Found ${warningCount} build warnings`,
        compliant: false,
      });
    }
    
    return findings;
  }

  private checkDataEncryption(project: Project) {
    // Check if data encryption is configured
    const encrypted = project.deploymentTarget === "eks" || project.deploymentTarget === "ecs";
    
    return {
      type: "data",
      severity: encrypted ? "low" : "high",
      title: "Data Encryption",
      description: encrypted ? "Data encryption is configured" : "Data encryption is not configured",
      compliant: encrypted,
    };
  }

  private checkDataRetention(project: Project) {
    // Check data retention policies
    return {
      type: "data",
      severity: "medium",
      title: "Data Retention Policy",
      description: "Data retention policies should be defined and implemented",
      compliant: true,
    };
  }

  private checkDataAccess(project: Project) {
    // Check data access controls
    return {
      type: "data",
      severity: "medium",
      title: "Data Access Controls",
      description: "Data access controls are properly configured",
      compliant: true,
    };
  }

  private checkRoleBasedAccess(project: Project) {
    // Check if RBAC is implemented
    const hasTeam = project.teamId !== null;
    
    return {
      type: "access_control",
      severity: hasTeam ? "low" : "medium",
      title: "Role-Based Access Control",
      description: hasTeam ? "RBAC is implemented" : "RBAC should be implemented",
      compliant: hasTeam,
    };
  }

  private checkPrincipleOfLeastPrivilege(project: Project) {
    // Check if principle of least privilege is followed
    return {
      type: "access_control",
      severity: "low",
      title: "Principle of Least Privilege",
      description: "Access permissions follow the principle of least privilege",
      compliant: true,
    };
  }

  private checkAuthenticationMethods(project: Project) {
    // Check authentication methods
    return {
      type: "access_control",
      severity: "low",
      title: "Authentication Methods",
      description: "Strong authentication methods are in use",
      compliant: true,
    };
  }

  private calculateOverallStatus(reports: any[]) {
    const hasNonCompliant = reports.some(report => report.status === "non-compliant");
    const hasPending = reports.some(report => report.status === "pending");
    
    if (hasNonCompliant) return "non-compliant";
    if (hasPending) return "pending";
    return "compliant";
  }

  private generateRecommendations(reports: any[]) {
    const recommendations = [];
    
    // Security recommendations
    const securityReport = reports.find(r => r.category === "security");
    if (securityReport?.status === "non-compliant") {
      recommendations.push({
        category: "security",
        priority: "high",
        title: "Address Security Issues",
        description: "Fix identified security vulnerabilities and implement security best practices",
        actions: [
          "Update dependencies with known vulnerabilities",
          "Implement proper secret management",
          "Enable security scanning in CI/CD pipeline",
          "Regular security audits",
        ],
      });
    }
    
    // Quality recommendations
    const qualityReport = reports.find(r => r.category === "quality");
    if (qualityReport?.status === "non-compliant") {
      recommendations.push({
        category: "quality",
        priority: "medium",
        title: "Improve Code Quality",
        description: "Implement code quality standards and increase test coverage",
        actions: [
          "Increase test coverage to at least 80%",
          "Fix linting issues",
          "Implement code reviews",
          "Add quality gates in CI/CD",
        ],
      });
    }
    
    // Data recommendations
    const dataReport = reports.find(r => r.category === "data");
    if (dataReport?.status === "non-compliant") {
      recommendations.push({
        category: "data",
        priority: "high",
        title: "Improve Data Protection",
        description: "Implement data protection and privacy controls",
        actions: [
          "Enable data encryption at rest and in transit",
          "Implement data retention policies",
          "Set up data access logging",
          "Regular data protection audits",
        ],
      });
    }
    
    return recommendations;
  }

  async logAuditEvent(userId: number, action: string, resourceType: string, resourceId: number, oldValues?: any, newValues?: any, ipAddress?: string, userAgent?: string) {
    try {
      await storage.createAuditLog({
        userId,
        action,
        resourceType,
        resourceId,
        oldValues,
        newValues,
        ipAddress,
        userAgent,
      });
    } catch (error) {
      console.error("Failed to log audit event:", error);
    }
  }
}

export const complianceService = new ComplianceService();