import type { Request, Response } from "express";
import crypto from "crypto";
import { storage } from "../storage";
import { autoBuildAgent } from "./agents";

export async function githubWebhookHandler(req: Request, res: Response) {
  try {
    const signature = req.headers['x-hub-signature-256'] as string;
    const payload = JSON.stringify(req.body);
    
    // Verify webhook signature
    if (!verifyGitHubWebhook(payload, signature, process.env.GITHUB_WEBHOOK_SECRET || '')) {
      return res.status(401).json({ error: "Invalid signature" });
    }

    const event = req.headers['x-github-event'] as string;
    
    if (event === 'push') {
      await handlePushEvent(req.body);
    } else if (event === 'pull_request') {
      await handlePullRequestEvent(req.body);
    }

    res.json({ success: true });
  } catch (error) {
    console.error("GitHub webhook error:", error);
    res.status(500).json({ error: "Webhook processing failed" });
  }
}

function verifyGitHubWebhook(payload: string, signature: string, secret: string): boolean {
  const hmac = crypto.createHmac('sha256', secret);
  hmac.update(payload);
  const expectedSignature = `sha256=${hmac.digest('hex')}`;
  return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature));
}

async function handlePushEvent(payload: any) {
  const repositoryUrl = payload.repository.html_url;
  const branch = payload.ref.replace('refs/heads/', '');
  const commitHash = payload.head_commit.id;

  // Find matching project
  const projects = await storage.getProjects();
  const project = projects.find(p => 
    p.repositoryUrl === repositoryUrl && p.branch === branch
  );

  if (!project) {
    console.log(`No project found for repository: ${repositoryUrl}, branch: ${branch}`);
    return;
  }

  // Trigger AutoBuild Agent
  await autoBuildAgent.triggerBuild(project, {
    commitHash,
    branch,
    author: payload.head_commit.author.name,
    message: payload.head_commit.message
  });
}

async function handlePullRequestEvent(payload: any) {
  if (payload.action !== 'opened' && payload.action !== 'synchronize') {
    return;
  }

  const repositoryUrl = payload.repository.html_url;
  const branch = payload.pull_request.head.ref;
  const commitHash = payload.pull_request.head.sha;

  // Find matching project
  const projects = await storage.getProjects();
  const project = projects.find(p => p.repositoryUrl === repositoryUrl);

  if (!project) {
    console.log(`No project found for repository: ${repositoryUrl}`);
    return;
  }

  // Trigger AutoBuild Agent for PR
  await autoBuildAgent.triggerBuild(project, {
    commitHash,
    branch,
    author: payload.pull_request.user.login,
    message: payload.pull_request.title,
    isPullRequest: true
  });
}

export function generateWebhookUrl(projectId: number): string {
  const baseUrl = process.env.REPLIT_DOMAINS?.split(',')[0] || 'localhost:5000';
  return `https://${baseUrl}/api/webhooks/github`;
}
