import { storage } from "../storage";
import { Project, Build, PerformanceMetric, InsertPerformanceMetric } from "@shared/schema";

export class MLOptimizationService {
  async analyzePerformance(project: Project, build: Build) {
    try {
      const metrics = await this.collectMetrics(project, build);
      const predictions = await this.generatePredictions(metrics);
      const suggestions = await this.generateOptimizationSuggestions(metrics, predictions);
      
      // Store metrics with ML predictions
      await storage.createPerformanceMetric({
        projectId: project.id,
        buildId: build.id,
        metricType: "ml_analysis",
        value: JSON.stringify(metrics),
        mlPredictions: predictions,
        optimizationSuggestions: suggestions,
      });
      
      return {
        metrics,
        predictions,
        suggestions,
      };
    } catch (error) {
      console.error("ML performance analysis failed:", error);
      return null;
    }
  }

  private async collectMetrics(project: Project, build: Build) {
    const metrics = {
      buildTime: build.duration || 0,
      buildNumber: build.buildNumber,
      projectType: project.projectType,
      deploymentTarget: project.deploymentTarget,
      cloudProvider: project.cloudProvider,
      timestamp: new Date().toISOString(),
    };
    
    // Collect additional metrics from build logs
    if (build.buildLogs) {
      metrics.buildDetails = this.extractBuildDetails(build.buildLogs);
    }
    
    // Collect test metrics
    if (build.testResults) {
      metrics.testMetrics = this.extractTestMetrics(build.testResults);
    }
    
    return metrics;
  }

  private extractBuildDetails(buildLogs: string) {
    const details = {
      dependencyInstallTime: 0,
      compilationTime: 0,
      testTime: 0,
      dockerBuildTime: 0,
    };
    
    // Extract timing information from logs
    const dependencyMatch = buildLogs.match(/Dependencies installed in (\d+)ms/);
    if (dependencyMatch) {
      details.dependencyInstallTime = parseInt(dependencyMatch[1]);
    }
    
    const compilationMatch = buildLogs.match(/Compilation completed in (\d+)ms/);
    if (compilationMatch) {
      details.compilationTime = parseInt(compilationMatch[1]);
    }
    
    const testMatch = buildLogs.match(/Tests completed in (\d+)ms/);
    if (testMatch) {
      details.testTime = parseInt(testMatch[1]);
    }
    
    const dockerMatch = buildLogs.match(/Docker build completed in (\d+)ms/);
    if (dockerMatch) {
      details.dockerBuildTime = parseInt(dockerMatch[1]);
    }
    
    return details;
  }

  private extractTestMetrics(testResults: any) {
    if (typeof testResults === 'string') {
      try {
        testResults = JSON.parse(testResults);
      } catch {
        return {};
      }
    }
    
    return {
      totalTests: testResults.totalTests || 0,
      passedTests: testResults.passedTests || 0,
      failedTests: testResults.failedTests || 0,
      coverage: testResults.coverage || 0,
      testDuration: testResults.testDuration || 0,
    };
  }

  private async generatePredictions(metrics: any) {
    // Simple ML-like predictions based on historical data
    const historicalData = await this.getHistoricalData(metrics.projectId);
    
    const predictions = {
      nextBuildTime: this.predictBuildTime(metrics, historicalData),
      successProbability: this.predictSuccessProbability(metrics, historicalData),
      resourceUsage: this.predictResourceUsage(metrics, historicalData),
      costEstimate: this.predictCost(metrics, historicalData),
    };
    
    return predictions;
  }

  private async getHistoricalData(projectId: number) {
    // Get recent builds for this project
    const builds = await storage.getBuilds(projectId, 20);
    const metrics = await storage.getPerformanceMetrics(projectId, 50);
    
    return {
      builds,
      metrics,
      averageBuildTime: builds.reduce((sum, b) => sum + (b.duration || 0), 0) / builds.length,
      successRate: builds.filter(b => b.status === "success").length / builds.length,
    };
  }

  private predictBuildTime(metrics: any, historicalData: any) {
    // Simple linear regression prediction
    const baseTime = historicalData.averageBuildTime || 300000; // 5 minutes default
    const projectTypeMultiplier = this.getProjectTypeMultiplier(metrics.projectType);
    const trendAdjustment = this.calculateTrendAdjustment(historicalData);
    
    const prediction = baseTime * projectTypeMultiplier * trendAdjustment;
    
    return {
      estimatedTime: Math.round(prediction),
      confidence: 0.75,
      factors: {
        projectType: projectTypeMultiplier,
        trend: trendAdjustment,
      },
    };
  }

  private predictSuccessProbability(metrics: any, historicalData: any) {
    let baseProbability = historicalData.successRate || 0.8;
    
    // Adjust based on project factors
    if (metrics.testMetrics?.coverage > 80) {
      baseProbability += 0.1;
    }
    
    if (metrics.buildDetails?.dependencyInstallTime > 300000) {
      baseProbability -= 0.05;
    }
    
    return {
      probability: Math.min(0.99, Math.max(0.01, baseProbability)),
      confidence: 0.7,
    };
  }

  private predictResourceUsage(metrics: any, historicalData: any) {
    const baseUsage = {
      cpu: 0.5,
      memory: 1024,
      storage: 2048,
    };
    
    // Adjust based on project type
    const multiplier = this.getProjectTypeMultiplier(metrics.projectType);
    
    return {
      cpu: baseUsage.cpu * multiplier,
      memory: baseUsage.memory * multiplier,
      storage: baseUsage.storage * multiplier,
      confidence: 0.6,
    };
  }

  private predictCost(metrics: any, historicalData: any) {
    const baseCost = 0.05; // $0.05 per build
    const cloudMultiplier = this.getCloudProviderMultiplier(metrics.cloudProvider);
    const resourceMultiplier = this.getProjectTypeMultiplier(metrics.projectType);
    
    return {
      estimated: baseCost * cloudMultiplier * resourceMultiplier,
      currency: "USD",
      confidence: 0.65,
    };
  }

  private getProjectTypeMultiplier(projectType: string) {
    const multipliers = {
      nodejs: 1.0,
      python: 1.2,
      java: 1.5,
      go: 0.8,
      docker: 1.3,
      auto: 1.1,
    };
    
    return multipliers[projectType] || 1.0;
  }

  private getCloudProviderMultiplier(cloudProvider: string) {
    const multipliers = {
      aws: 1.0,
      gcp: 0.9,
      azure: 1.1,
    };
    
    return multipliers[cloudProvider] || 1.0;
  }

  private calculateTrendAdjustment(historicalData: any) {
    if (!historicalData.builds || historicalData.builds.length < 3) {
      return 1.0;
    }
    
    // Calculate if build times are trending up or down
    const recent = historicalData.builds.slice(-3);
    const older = historicalData.builds.slice(-6, -3);
    
    if (recent.length === 0 || older.length === 0) {
      return 1.0;
    }
    
    const recentAvg = recent.reduce((sum, b) => sum + (b.duration || 0), 0) / recent.length;
    const olderAvg = older.reduce((sum, b) => sum + (b.duration || 0), 0) / older.length;
    
    if (olderAvg === 0) return 1.0;
    
    const trend = recentAvg / olderAvg;
    return Math.min(2.0, Math.max(0.5, trend));
  }

  private async generateOptimizationSuggestions(metrics: any, predictions: any) {
    const suggestions = [];
    
    // Build time optimization
    if (predictions.nextBuildTime.estimatedTime > 600000) { // > 10 minutes
      suggestions.push({
        type: "build_optimization",
        priority: "high",
        title: "Optimize Build Time",
        description: "Build time is predicted to be over 10 minutes. Consider optimizing dependencies or using build caching.",
        actions: [
          "Enable build caching",
          "Optimize dependency installation",
          "Use multi-stage Docker builds",
          "Parallelize build steps",
        ],
      });
    }
    
    // Test optimization
    if (metrics.testMetrics?.testDuration > 300000) { // > 5 minutes
      suggestions.push({
        type: "test_optimization",
        priority: "medium",
        title: "Optimize Test Execution",
        description: "Test execution time is high. Consider parallel testing or test optimization.",
        actions: [
          "Run tests in parallel",
          "Optimize slow tests",
          "Use test result caching",
          "Split test suites",
        ],
      });
    }
    
    // Resource optimization
    if (predictions.resourceUsage.memory > 2048) {
      suggestions.push({
        type: "resource_optimization",
        priority: "medium",
        title: "Optimize Resource Usage",
        description: "High memory usage predicted. Consider optimizing resource allocation.",
        actions: [
          "Optimize memory usage",
          "Use smaller base images",
          "Implement resource limits",
          "Monitor memory leaks",
        ],
      });
    }
    
    // Cost optimization
    if (predictions.costEstimate.estimated > 0.10) {
      suggestions.push({
        type: "cost_optimization",
        priority: "low",
        title: "Optimize Costs",
        description: "Build costs are higher than average. Consider cost optimization strategies.",
        actions: [
          "Use spot instances",
          "Optimize build frequency",
          "Implement build caching",
          "Use cheaper regions",
        ],
      });
    }
    
    return suggestions;
  }
}

export const mlOptimizationService = new MLOptimizationService();