import { 
  users, projects, builds, deployments, agents, notifications, teams, auditLogs, performanceMetrics, complianceReports,
  type User, type InsertUser, type Project, type InsertProject,
  type Build, type InsertBuild, type Deployment, type InsertDeployment,
  type Agent, type InsertAgent, type Notification, type InsertNotification,
  type Team, type InsertTeam, type AuditLog, type InsertAuditLog,
  type PerformanceMetric, type InsertPerformanceMetric, type ComplianceReport, type InsertComplianceReport
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, sql } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Projects
  getProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project>;
  deleteProject(id: number): Promise<void>;

  // Builds
  getBuilds(projectId?: number, limit?: number): Promise<Build[]>;
  getBuild(id: number): Promise<Build | undefined>;
  createBuild(build: InsertBuild): Promise<Build>;
  updateBuild(id: number, build: Partial<InsertBuild>): Promise<Build>;
  getRecentBuilds(limit: number): Promise<Build[]>;

  // Deployments
  getDeployments(projectId?: number, limit?: number): Promise<Deployment[]>;
  getDeployment(id: number): Promise<Deployment | undefined>;
  createDeployment(deployment: InsertDeployment): Promise<Deployment>;
  updateDeployment(id: number, deployment: Partial<InsertDeployment>): Promise<Deployment>;

  // Agents
  getAgents(): Promise<Agent[]>;
  getAgent(id: number): Promise<Agent | undefined>;
  createAgent(agent: InsertAgent): Promise<Agent>;
  updateAgent(id: number, agent: Partial<InsertAgent>): Promise<Agent>;
  updateAgentHeartbeat(id: number): Promise<void>;

  // Notifications
  getNotifications(isRead?: boolean, limit?: number): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<void>;

  // Teams
  getTeams(): Promise<Team[]>;
  getTeam(id: number): Promise<Team | undefined>;
  createTeam(team: InsertTeam): Promise<Team>;
  updateTeam(id: number, team: Partial<InsertTeam>): Promise<Team>;
  deleteTeam(id: number): Promise<void>;

  // Audit Logs
  getAuditLogs(userId?: number, projectId?: number, limit?: number): Promise<AuditLog[]>;
  createAuditLog(auditLog: InsertAuditLog): Promise<AuditLog>;

  // Performance Metrics
  getPerformanceMetrics(projectId: number, limit?: number): Promise<PerformanceMetric[]>;
  createPerformanceMetric(metric: InsertPerformanceMetric): Promise<PerformanceMetric>;

  // Compliance Reports
  getComplianceReports(projectId?: number, limit?: number): Promise<ComplianceReport[]>;
  getComplianceReport(id: number): Promise<ComplianceReport | undefined>;
  createComplianceReport(report: InsertComplianceReport): Promise<ComplianceReport>;

  // Analytics
  getProjectStats(): Promise<{
    totalProjects: number;
    activeProjects: number;
    successRate: number;
    avgDeployTime: number;
    monthlyCost: number;
  }>;
  getSecurityStats(): Promise<{
    criticalVulnerabilities: number;
    highPriorityIssues: number;
    securityScore: string;
  }>;
  getCostStats(): Promise<{
    monthlySavings: number;
    resourceEfficiency: number;
    recommendations: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Projects
  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects).orderBy(desc(projects.createdAt));
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project || undefined;
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [created] = await db.insert(projects).values(project).returning();
    return created;
  }

  async updateProject(id: number, project: Partial<InsertProject>): Promise<Project> {
    const [updated] = await db.update(projects)
      .set({ ...project, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return updated;
  }

  async deleteProject(id: number): Promise<void> {
    await db.delete(projects).where(eq(projects.id, id));
  }

  // Builds
  async getBuilds(projectId?: number, limit = 50): Promise<Build[]> {
    const query = db.select().from(builds);
    if (projectId) {
      return await query.where(eq(builds.projectId, projectId))
        .orderBy(desc(builds.startedAt))
        .limit(limit);
    }
    return await query.orderBy(desc(builds.startedAt)).limit(limit);
  }

  async getBuild(id: number): Promise<Build | undefined> {
    const [build] = await db.select().from(builds).where(eq(builds.id, id));
    return build || undefined;
  }

  async createBuild(build: InsertBuild): Promise<Build> {
    const [created] = await db.insert(builds).values(build).returning();
    return created;
  }

  async updateBuild(id: number, build: Partial<InsertBuild>): Promise<Build> {
    const [updated] = await db.update(builds)
      .set(build)
      .where(eq(builds.id, id))
      .returning();
    return updated;
  }

  async getRecentBuilds(limit: number): Promise<Build[]> {
    return await db.select().from(builds)
      .orderBy(desc(builds.startedAt))
      .limit(limit);
  }

  // Deployments
  async getDeployments(projectId?: number, limit = 50): Promise<Deployment[]> {
    const query = db.select().from(deployments);
    if (projectId) {
      return await query.where(eq(deployments.projectId, projectId))
        .orderBy(desc(deployments.deployedAt))
        .limit(limit);
    }
    return await query.orderBy(desc(deployments.deployedAt)).limit(limit);
  }

  async getDeployment(id: number): Promise<Deployment | undefined> {
    const [deployment] = await db.select().from(deployments).where(eq(deployments.id, id));
    return deployment || undefined;
  }

  async createDeployment(deployment: InsertDeployment): Promise<Deployment> {
    const [created] = await db.insert(deployments).values(deployment).returning();
    return created;
  }

  async updateDeployment(id: number, deployment: Partial<InsertDeployment>): Promise<Deployment> {
    const [updated] = await db.update(deployments)
      .set(deployment)
      .where(eq(deployments.id, id))
      .returning();
    return updated;
  }

  // Agents
  async getAgents(): Promise<Agent[]> {
    return await db.select().from(agents).orderBy(agents.name);
  }

  async getAgent(id: number): Promise<Agent | undefined> {
    const [agent] = await db.select().from(agents).where(eq(agents.id, id));
    return agent || undefined;
  }

  async createAgent(agent: InsertAgent): Promise<Agent> {
    const [created] = await db.insert(agents).values(agent).returning();
    return created;
  }

  async updateAgent(id: number, agent: Partial<InsertAgent>): Promise<Agent> {
    const [updated] = await db.update(agents)
      .set(agent)
      .where(eq(agents.id, id))
      .returning();
    return updated;
  }

  async updateAgentHeartbeat(id: number): Promise<void> {
    await db.update(agents)
      .set({ lastHeartbeat: new Date() })
      .where(eq(agents.id, id));
  }

  // Notifications
  async getNotifications(isRead?: boolean, limit = 50): Promise<Notification[]> {
    const query = db.select().from(notifications);
    if (isRead !== undefined) {
      return await query.where(eq(notifications.isRead, isRead))
        .orderBy(desc(notifications.createdAt))
        .limit(limit);
    }
    return await query.orderBy(desc(notifications.createdAt)).limit(limit);
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [created] = await db.insert(notifications).values(notification).returning();
    return created;
  }

  async markNotificationAsRead(id: number): Promise<void> {
    await db.update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id));
  }

  // Analytics
  async getProjectStats(): Promise<{
    totalProjects: number;
    activeProjects: number;
    successRate: number;
    avgDeployTime: number;
    monthlyCost: number;
  }> {
    const [totalProjects] = await db.select({ count: sql<number>`count(*)` }).from(projects);
    const [activeProjects] = await db.select({ count: sql<number>`count(*)` }).from(projects)
      .where(eq(projects.isActive, true));
    
    const [successData] = await db.select({ 
      total: sql<number>`count(*)`,
      success: sql<number>`count(case when status = 'success' then 1 end)`
    }).from(builds);

    const [avgTime] = await db.select({
      avgDuration: sql<number>`avg(duration)`
    }).from(builds).where(eq(builds.status, 'success'));

    return {
      totalProjects: totalProjects.count,
      activeProjects: activeProjects.count,
      successRate: successData.total > 0 ? (successData.success / successData.total) * 100 : 0,
      avgDeployTime: avgTime.avgDuration || 0,
      monthlyCost: 342 // This would come from AWS Cost Explorer API
    };
  }

  async getSecurityStats(): Promise<{
    criticalVulnerabilities: number;
    highPriorityIssues: number;
    securityScore: string;
  }> {
    // This would analyze security scan results from builds
    return {
      criticalVulnerabilities: 2,
      highPriorityIssues: 7,
      securityScore: 'B+'
    };
  }

  async getCostStats(): Promise<{
    monthlySavings: number;
    resourceEfficiency: number;
    recommendations: number;
  }> {
    // This would come from cost optimization analysis
    return {
      monthlySavings: 89,
      resourceEfficiency: 87,
      recommendations: 5
    };
  }

  // Teams
  async getTeams(): Promise<Team[]> {
    return await db.select().from(teams);
  }

  async getTeam(id: number): Promise<Team | undefined> {
    const [team] = await db.select().from(teams).where(eq(teams.id, id));
    return team || undefined;
  }

  async createTeam(team: InsertTeam): Promise<Team> {
    const [newTeam] = await db.insert(teams).values(team).returning();
    return newTeam;
  }

  async updateTeam(id: number, team: Partial<InsertTeam>): Promise<Team> {
    const [updatedTeam] = await db.update(teams).set(team).where(eq(teams.id, id)).returning();
    return updatedTeam;
  }

  async deleteTeam(id: number): Promise<void> {
    await db.delete(teams).where(eq(teams.id, id));
  }

  // Audit Logs
  async getAuditLogs(userId?: number, projectId?: number, limit = 100): Promise<AuditLog[]> {
    if (userId || projectId) {
      const conditions = [];
      if (userId) conditions.push(eq(auditLogs.userId, userId));
      if (projectId) conditions.push(eq(auditLogs.projectId, projectId));
      
      return await db.select().from(auditLogs)
        .where(and(...conditions))
        .orderBy(desc(auditLogs.timestamp))
        .limit(limit);
    }
    
    return await db.select().from(auditLogs)
      .orderBy(desc(auditLogs.timestamp))
      .limit(limit);
  }

  async createAuditLog(auditLog: InsertAuditLog): Promise<AuditLog> {
    const [newAuditLog] = await db.insert(auditLogs).values(auditLog).returning();
    return newAuditLog;
  }

  // Performance Metrics
  async getPerformanceMetrics(projectId: number, limit = 100): Promise<PerformanceMetric[]> {
    return await db.select().from(performanceMetrics)
      .where(eq(performanceMetrics.projectId, projectId))
      .orderBy(desc(performanceMetrics.timestamp))
      .limit(limit);
  }

  async createPerformanceMetric(metric: InsertPerformanceMetric): Promise<PerformanceMetric> {
    const [newMetric] = await db.insert(performanceMetrics).values(metric).returning();
    return newMetric;
  }

  // Compliance Reports
  async getComplianceReports(projectId?: number, limit = 50): Promise<ComplianceReport[]> {
    if (projectId) {
      return await db.select().from(complianceReports)
        .where(eq(complianceReports.projectId, projectId))
        .orderBy(desc(complianceReports.generatedAt))
        .limit(limit);
    }
    
    return await db.select().from(complianceReports)
      .orderBy(desc(complianceReports.generatedAt))
      .limit(limit);
  }

  async getComplianceReport(id: number): Promise<ComplianceReport | undefined> {
    const [report] = await db.select().from(complianceReports).where(eq(complianceReports.id, id));
    return report || undefined;
  }

  async createComplianceReport(report: InsertComplianceReport): Promise<ComplianceReport> {
    const [newReport] = await db.insert(complianceReports).values(report).returning();
    return newReport;
  }
}

export const storage = new DatabaseStorage();
