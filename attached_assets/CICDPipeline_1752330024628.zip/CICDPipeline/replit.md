# PipelineForge - CI/CD Automation Platform

## Overview

PipelineForge is a full-stack web application that automates Continuous Integration (CI) and Continuous Deployment (CD) workflows using intelligent agents. The platform provides automated project detection, dynamic tooling, containerization, and deployment to AWS infrastructure (ECS/EKS) with built-in security scanning and cost optimization.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

- ✅ Added Security dashboard with vulnerability tracking, compliance monitoring, and security trends
- ✅ Created Cost Analytics page with cost breakdown, optimization recommendations, and forecasting
- ✅ Built comprehensive Monitoring dashboard with system health, agents status, and real-time logs
- ✅ Implemented Teams management with CRUD operations and team collaboration features
- ✅ Added Settings page with profile, notifications, security, integrations, and preferences
- ✅ Created comprehensive Tech Overview document with enhanced UI, colors, and symbols
- ✅ Updated router to include all new pages and fixed navigation issues
- ✅ Enhanced sidebar with proper navigation links and icons
- ✅ Added comprehensive API endpoints for teams, compliance, metrics, and audit logs
- ✅ Integrated GitLab and Bitbucket webhook support alongside GitHub
- ✅ Implemented multi-cloud deployment methods in DeployMaster agent

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **UI Library**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with custom theming for dark mode
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ESM modules
- **Database**: PostgreSQL with Drizzle ORM
- **WebSocket**: ws library for real-time updates
- **Authentication**: Session-based (connect-pg-simple)

### Database Schema
The application uses a relational database with the following key entities:
- **Users**: Authentication and user management
- **Projects**: Repository configurations and deployment settings
- **Builds**: CI pipeline execution records
- **Deployments**: CD pipeline execution records  
- **Agents**: Intelligent automation agents status
- **Notifications**: System alerts and updates

## Key Components

### Intelligent Agents
Four specialized agents handle different aspects of the CI/CD pipeline:

1. **AutoBuild Agent**: Handles CI operations including project detection, dependency installation, testing, and containerization
2. **DeployMaster Agent**: Manages CD operations and AWS deployments
3. **SecureGuard Agent**: Performs security scanning and vulnerability assessment
4. **CostOptimizer Agent**: Monitors and optimizes resource usage and costs

### Project Detection System
- Automatic project type detection based on configuration files
- Support for Node.js, Python, Java, Go, and Docker projects
- Dynamic tool installation and build process adaptation

### AWS Integration
- ECS and EKS deployment support
- ECR for container registry
- Cost Explorer integration for usage monitoring
- Configurable AWS credentials per project

### Real-time Updates
- WebSocket connections for live build logs and status updates
- Real-time dashboard updates for pipeline status
- Live notifications for important events

## Data Flow

1. **Webhook Trigger**: GitHub webhooks trigger CI/CD pipelines on code changes
2. **Build Process**: AutoBuild agent processes the repository through detection, building, testing, and containerization
3. **Security Scan**: SecureGuard agent performs vulnerability scanning
4. **Deployment**: DeployMaster agent handles AWS deployment
5. **Monitoring**: CostOptimizer agent tracks resource usage and costs
6. **Notifications**: Real-time updates sent to frontend via WebSocket

## External Dependencies

### Core Dependencies
- **Database**: Neon PostgreSQL serverless database
- **AWS Services**: ECS, EKS, ECR, Cost Explorer APIs
- **Version Control**: GitHub API and webhook integration
- **UI Components**: Radix UI primitives for accessibility
- **Form Handling**: React Hook Form with Zod validation

### Development Tools
- **Database Migration**: Drizzle Kit for schema management
- **Build System**: ESBuild for server bundling, Vite for client bundling
- **Type Safety**: TypeScript with strict configuration
- **Code Quality**: ESLint integration planned

## Deployment Strategy

### Production Build
- Client assets built with Vite and served statically
- Server bundled with ESBuild for Node.js runtime
- Database migrations handled via Drizzle Kit
- Environment-based configuration for different stages

### Infrastructure Requirements
- Node.js runtime environment
- PostgreSQL database connection
- AWS credentials for service integration
- WebSocket support for real-time features

### Environment Configuration
- `DATABASE_URL`: PostgreSQL connection string
- `GITHUB_WEBHOOK_SECRET`: GitHub webhook validation
- `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY`: AWS service access
- `NODE_ENV`: Environment stage configuration

The application is designed to be deployed on platforms supporting Node.js with PostgreSQL, with the ability to scale the intelligent agents as separate services if needed.