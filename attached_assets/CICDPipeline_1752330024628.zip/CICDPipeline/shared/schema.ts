import { pgTable, text, serial, integer, boolean, timestamp, json, pgEnum } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const projectTypeEnum = pgEnum("project_type", ["nodejs", "python", "java", "go", "docker", "auto"]);
export const deploymentTargetEnum = pgEnum("deployment_target", ["ecs", "eks", "gke", "aks", "cloud-run", "app-service"]);
export const buildStatusEnum = pgEnum("build_status", ["pending", "running", "success", "failed", "cancelled"]);
export const agentStatusEnum = pgEnum("agent_status", ["active", "inactive", "error"]);
export const repositoryProviderEnum = pgEnum("repository_provider", ["github", "gitlab", "bitbucket"]);
export const cloudProviderEnum = pgEnum("cloud_provider", ["aws", "gcp", "azure"]);
export const userRoleEnum = pgEnum("user_role", ["admin", "developer", "viewer"]);
export const complianceStatusEnum = pgEnum("compliance_status", ["compliant", "non-compliant", "pending"]);

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  role: userRoleEnum("role").notNull().default("developer"),
  teamId: integer("team_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  ownerId: integer("owner_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  projectId: integer("project_id").references(() => projects.id),
  action: text("action").notNull(),
  resourceType: text("resource_type").notNull(),
  resourceId: integer("resource_id"),
  oldValues: json("old_values"),
  newValues: json("new_values"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const performanceMetrics = pgTable("performance_metrics", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  buildId: integer("build_id").references(() => builds.id),
  metricType: text("metric_type").notNull(), // build_time, test_coverage, deploy_time, etc.
  value: text("value").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
  mlPredictions: json("ml_predictions"),
  optimizationSuggestions: json("optimization_suggestions"),
});

export const complianceReports = pgTable("compliance_reports", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  reportType: text("report_type").notNull(), // security, quality, compliance
  status: complianceStatusEnum("status").notNull(),
  findings: json("findings"),
  recommendations: json("recommendations"),
  generatedAt: timestamp("generated_at").defaultNow(),
  validUntil: timestamp("valid_until"),
});

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  repositoryUrl: text("repository_url").notNull(),
  repositoryProvider: repositoryProviderEnum("repository_provider").notNull().default("github"),
  branch: text("branch").notNull().default("main"),
  projectType: projectTypeEnum("project_type").notNull().default("auto"),
  deploymentTarget: deploymentTargetEnum("deployment_target").notNull(),
  cloudProvider: cloudProviderEnum("cloud_provider").notNull().default("aws"),
  clusterName: text("cluster_name").notNull(),
  serviceName: text("service_name").notNull(),
  environmentVariables: json("environment_variables"),
  awsCredentials: json("aws_credentials"),
  gcpCredentials: json("gcp_credentials"),
  azureCredentials: json("azure_credentials"),
  webhookSecret: text("webhook_secret"),
  isActive: boolean("is_active").default(true),
  teamId: integer("team_id"),
  complianceStatus: complianceStatusEnum("compliance_status").default("pending"),
  monitoringEnabled: boolean("monitoring_enabled").default(true),
  performanceOptimized: boolean("performance_optimized").default(false),
  customMetrics: json("custom_metrics"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const builds = pgTable("builds", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  buildNumber: integer("build_number").notNull(),
  commitHash: text("commit_hash").notNull(),
  branch: text("branch").notNull(),
  status: buildStatusEnum("status").notNull().default("pending"),
  dockerImageUrl: text("docker_image_url"),
  buildLogs: text("build_logs"),
  testResults: json("test_results"),
  securityScanResults: json("security_scan_results"),
  costMetrics: json("cost_metrics"),
  duration: integer("duration"),
  startedAt: timestamp("started_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const deployments = pgTable("deployments", {
  id: serial("id").primaryKey(),
  buildId: integer("build_id").references(() => builds.id).notNull(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  status: buildStatusEnum("status").notNull().default("pending"),
  deploymentLogs: text("deployment_logs"),
  healthCheckStatus: text("health_check_status"),
  rollbackDeploymentId: integer("rollback_deployment_id"),
  deployedAt: timestamp("deployed_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const agents = pgTable("agents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // autobuild, deploymaster, secureguard, costoptimizer
  status: agentStatusEnum("status").notNull().default("active"),
  configuration: json("configuration"),
  lastHeartbeat: timestamp("last_heartbeat").defaultNow(),
  metrics: json("metrics"),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id),
  buildId: integer("build_id").references(() => builds.id),
  type: text("type").notNull(), // success, failure, warning
  title: text("title").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  team: one(teams, {
    fields: [users.teamId],
    references: [teams.id],
  }),
  auditLogs: many(auditLogs),
}));

export const teamsRelations = relations(teams, ({ one, many }) => ({
  owner: one(users, {
    fields: [teams.ownerId],
    references: [users.id],
  }),
  members: many(users),
  projects: many(projects),
}));

export const projectsRelations = relations(projects, ({ one, many }) => ({
  team: one(teams, {
    fields: [projects.teamId],
    references: [teams.id],
  }),
  builds: many(builds),
  deployments: many(deployments),
  notifications: many(notifications),
  auditLogs: many(auditLogs),
  performanceMetrics: many(performanceMetrics),
  complianceReports: many(complianceReports),
}));

export const buildsRelations = relations(builds, ({ one, many }) => ({
  project: one(projects, {
    fields: [builds.projectId],
    references: [projects.id],
  }),
  deployments: many(deployments),
  performanceMetrics: many(performanceMetrics),
}));

export const auditLogsRelations = relations(auditLogs, ({ one }) => ({
  user: one(users, {
    fields: [auditLogs.userId],
    references: [users.id],
  }),
  project: one(projects, {
    fields: [auditLogs.projectId],
    references: [projects.id],
  }),
}));

export const performanceMetricsRelations = relations(performanceMetrics, ({ one }) => ({
  project: one(projects, {
    fields: [performanceMetrics.projectId],
    references: [projects.id],
  }),
  build: one(builds, {
    fields: [performanceMetrics.buildId],
    references: [builds.id],
  }),
}));

export const complianceReportsRelations = relations(complianceReports, ({ one }) => ({
  project: one(projects, {
    fields: [complianceReports.projectId],
    references: [projects.id],
  }),
}));

export const deploymentsRelations = relations(deployments, ({ one }) => ({
  build: one(builds, {
    fields: [deployments.buildId],
    references: [builds.id],
  }),
  project: one(projects, {
    fields: [deployments.projectId],
    references: [projects.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  project: one(projects, {
    fields: [notifications.projectId],
    references: [projects.id],
  }),
  build: one(builds, {
    fields: [notifications.buildId],
    references: [builds.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBuildSchema = createInsertSchema(builds).omit({
  id: true,
  startedAt: true,
  completedAt: true,
});

export const insertDeploymentSchema = createInsertSchema(deployments).omit({
  id: true,
  deployedAt: true,
  completedAt: true,
});

export const insertAgentSchema = createInsertSchema(agents).omit({
  id: true,
  lastHeartbeat: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export const insertTeamSchema = createInsertSchema(teams).omit({
  id: true,
  createdAt: true,
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({
  id: true,
  timestamp: true,
});

export const insertPerformanceMetricSchema = createInsertSchema(performanceMetrics).omit({
  id: true,
  timestamp: true,
});

export const insertComplianceReportSchema = createInsertSchema(complianceReports).omit({
  id: true,
  generatedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Build = typeof builds.$inferSelect;
export type InsertBuild = z.infer<typeof insertBuildSchema>;
export type Deployment = typeof deployments.$inferSelect;
export type InsertDeployment = z.infer<typeof insertDeploymentSchema>;
export type Agent = typeof agents.$inferSelect;
export type InsertAgent = z.infer<typeof insertAgentSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Team = typeof teams.$inferSelect;
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type PerformanceMetric = typeof performanceMetrics.$inferSelect;
export type InsertPerformanceMetric = z.infer<typeof insertPerformanceMetricSchema>;
export type ComplianceReport = typeof complianceReports.$inferSelect;
export type InsertComplianceReport = z.infer<typeof insertComplianceReportSchema>;
