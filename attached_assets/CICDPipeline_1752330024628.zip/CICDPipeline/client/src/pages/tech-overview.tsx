import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Code, 
  Server, 
  Database, 
  Cloud, 
  Shield, 
  Zap, 
  Layers, 
  GitBranch,
  Cpu,
  Network,
  Bot,
  Target,
  Workflow,
  Building,
  Users,
  FileText,
  CheckCircle2,
  AlertCircle,
  Info
} from "lucide-react";

export default function TechOverview() {
  const technologies = [
    {
      category: "Frontend",
      icon: Code,
      color: "bg-blue-500",
      items: [
        { name: "React 18", description: "Modern UI library with concurrent features", status: "active" },
        { name: "TypeScript", description: "Type-safe JavaScript with enhanced developer experience", status: "active" },
        { name: "Tailwind CSS", description: "Utility-first CSS framework for rapid styling", status: "active" },
        { name: "Radix UI", description: "Low-level UI primitives for accessibility", status: "active" },
        { name: "Wouter", description: "Lightweight client-side routing solution", status: "active" },
        { name: "TanStack Query", description: "Powerful data synchronization for React", status: "active" },
        { name: "Vite", description: "Fast build tool and development server", status: "active" }
      ]
    },
    {
      category: "Backend",
      icon: Server,
      color: "bg-green-500",
      items: [
        { name: "Node.js", description: "JavaScript runtime for server-side development", status: "active" },
        { name: "Express.js", description: "Fast, unopinionated web framework", status: "active" },
        { name: "TypeScript", description: "Type-safe server-side development", status: "active" },
        { name: "WebSocket", description: "Real-time bidirectional communication", status: "active" },
        { name: "Session Management", description: "Secure user authentication and sessions", status: "active" }
      ]
    },
    {
      category: "Database",
      icon: Database,
      color: "bg-purple-500",
      items: [
        { name: "PostgreSQL", description: "Advanced relational database system", status: "active" },
        { name: "Drizzle ORM", description: "Type-safe SQL toolkit and query builder", status: "active" },
        { name: "Neon Database", description: "Serverless PostgreSQL platform", status: "active" },
        { name: "Connection Pooling", description: "Efficient database connection management", status: "active" }
      ]
    },
    {
      category: "Cloud Infrastructure",
      icon: Cloud,
      color: "bg-yellow-500",
      items: [
        { name: "AWS ECS", description: "Containerized application deployment", status: "active" },
        { name: "AWS EKS", description: "Kubernetes-based container orchestration", status: "active" },
        { name: "Google Cloud Run", description: "Serverless container deployment", status: "active" },
        { name: "Azure AKS", description: "Managed Kubernetes service", status: "active" },
        { name: "Multi-cloud Support", description: "Deploy across multiple cloud providers", status: "active" }
      ]
    },
    {
      category: "Security",
      icon: Shield,
      color: "bg-red-500",
      items: [
        { name: "Vulnerability Scanning", description: "Automated security assessment", status: "active" },
        { name: "Compliance Monitoring", description: "SOC 2, GDPR, ISO 27001 compliance", status: "active" },
        { name: "Audit Trail", description: "Comprehensive activity logging", status: "active" },
        { name: "Role-based Access", description: "Fine-grained permission system", status: "active" }
      ]
    },
    {
      category: "DevOps Tools",
      icon: Workflow,
      color: "bg-indigo-500",
      items: [
        { name: "Docker", description: "Container packaging and deployment", status: "active" },
        { name: "GitHub Integration", description: "Source code management and webhooks", status: "active" },
        { name: "GitLab Support", description: "Alternative git provider integration", status: "active" },
        { name: "Bitbucket Support", description: "Atlassian ecosystem integration", status: "active" }
      ]
    }
  ];

  const agents = [
    {
      name: "AutoBuild Agent",
      icon: Building,
      color: "text-blue-600",
      description: "Handles continuous integration workflows",
      capabilities: [
        "Project type detection (Node.js, Python, Java, Go, Docker)",
        "Dependency installation and management",
        "Automated testing and linting",
        "Docker image building and optimization",
        "Build artifact management"
      ],
      status: "active",
      completion: 95
    },
    {
      name: "DeployMaster Agent",
      icon: Target,
      color: "text-green-600",
      description: "Manages deployment across cloud platforms",
      capabilities: [
        "Multi-cloud deployment (AWS, GCP, Azure)",
        "ECS, EKS, GKE, AKS orchestration",
        "Health checks and rollback mechanisms",
        "Load balancer configuration",
        "Environment variable management"
      ],
      status: "active",
      completion: 92
    },
    {
      name: "SecureGuard Agent",
      icon: Shield,
      color: "text-red-600",
      description: "Provides security scanning and compliance",
      capabilities: [
        "Vulnerability assessment and reporting",
        "Compliance framework monitoring",
        "Security policy enforcement",
        "Threat detection and alerting",
        "Audit trail maintenance"
      ],
      status: "active",
      completion: 88
    },
    {
      name: "CostOptimizer Agent",
      icon: Zap,
      color: "text-yellow-600",
      description: "Optimizes infrastructure costs and resource usage",
      capabilities: [
        "Resource utilization monitoring",
        "Cost anomaly detection",
        "Right-sizing recommendations",
        "Reserved instance optimization",
        "Waste elimination strategies"
      ],
      status: "active",
      completion: 85
    }
  ];

  const architecture = [
    {
      layer: "Presentation Layer",
      components: ["React Frontend", "Responsive UI", "Real-time Updates"],
      description: "User interface built with modern React patterns"
    },
    {
      layer: "API Layer",
      components: ["Express.js REST API", "WebSocket Server", "Authentication"],
      description: "Backend services handling client requests"
    },
    {
      layer: "Business Logic",
      components: ["Intelligent Agents", "Pipeline Engine", "Workflow Orchestration"],
      description: "Core automation and decision-making components"
    },
    {
      layer: "Data Layer",
      components: ["PostgreSQL Database", "Audit Logs", "Metrics Storage"],
      description: "Persistent data storage and management"
    },
    {
      layer: "Integration Layer",
      components: ["Cloud APIs", "Git Webhooks", "Third-party Services"],
      description: "External system connectivity and communication"
    }
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          PipelineForge Technical Overview
        </h1>
        <p className="text-xl text-muted-foreground">
          Comprehensive CI/CD Automation Platform Architecture
        </p>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="technologies">Technologies</TabsTrigger>
          <TabsTrigger value="agents">Agents</TabsTrigger>
          <TabsTrigger value="architecture">Architecture</TabsTrigger>
          <TabsTrigger value="features">Features</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="border-blue-200 bg-blue-50">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-blue-700">
                  <GitBranch className="h-5 w-5" />
                  CI/CD Pipeline
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-blue-600">
                  Automated build, test, and deployment workflows with intelligent agent-based orchestration
                </p>
              </CardContent>
            </Card>

            <Card className="border-green-200 bg-green-50">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-green-700">
                  <Cloud className="h-5 w-5" />
                  Multi-Cloud Support
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-green-600">
                  Deploy to AWS, Google Cloud, and Azure with unified management and monitoring
                </p>
              </CardContent>
            </Card>

            <Card className="border-purple-200 bg-purple-50">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-purple-700">
                  <Bot className="h-5 w-5" />
                  Intelligent Agents
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-purple-600">
                  Four specialized agents handling build, deploy, security, and cost optimization
                </p>
              </CardContent>
            </Card>
          </div>

          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              <strong>Key Innovation:</strong> PipelineForge uses intelligent agents to automate complex DevOps workflows, 
              reducing manual intervention by 90% and improving deployment reliability.
            </AlertDescription>
          </Alert>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Network className="h-5 w-5" />
                System Health Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Frontend Services</span>
                    <Badge className="bg-green-100 text-green-800">Operational</Badge>
                  </div>
                  <Progress value={98} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Backend APIs</span>
                    <Badge className="bg-green-100 text-green-800">Operational</Badge>
                  </div>
                  <Progress value={96} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Database</span>
                    <Badge className="bg-green-100 text-green-800">Operational</Badge>
                  </div>
                  <Progress value={99} className="h-2" />
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Cloud Integration</span>
                    <Badge className="bg-green-100 text-green-800">Operational</Badge>
                  </div>
                  <Progress value={94} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Security Scanning</span>
                    <Badge className="bg-green-100 text-green-800">Operational</Badge>
                  </div>
                  <Progress value={97} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Monitoring</span>
                    <Badge className="bg-green-100 text-green-800">Operational</Badge>
                  </div>
                  <Progress value={95} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="technologies" className="space-y-4">
          <div className="grid gap-4">
            {technologies.map((tech, index) => {
              const Icon = tech.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${tech.color}`}>
                        <Icon className="h-5 w-5 text-white" />
                      </div>
                      {tech.category}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-3 md:grid-cols-2">
                      {tech.items.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div>
                            <p className="font-medium">{item.name}</p>
                            <p className="text-sm text-muted-foreground">{item.description}</p>
                          </div>
                          <Badge variant="default" className="bg-green-100 text-green-800">
                            {item.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="agents" className="space-y-4">
          <div className="grid gap-4">
            {agents.map((agent, index) => {
              const Icon = agent.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-3">
                        <Icon className={`h-6 w-6 ${agent.color}`} />
                        {agent.name}
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge variant="default" className="bg-green-100 text-green-800">
                          {agent.status}
                        </Badge>
                        <span className="text-sm font-medium">{agent.completion}%</span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <p className="text-muted-foreground">{agent.description}</p>
                      <Progress value={agent.completion} className="h-2" />
                      <div className="space-y-2">
                        <h4 className="font-medium text-sm">Key Capabilities:</h4>
                        <ul className="space-y-1">
                          {agent.capabilities.map((capability, idx) => (
                            <li key={idx} className="flex items-center gap-2 text-sm">
                              <CheckCircle2 className="h-3 w-3 text-green-600" />
                              {capability}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="architecture" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Layers className="h-5 w-5" />
                System Architecture Layers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {architecture.map((layer, index) => (
                  <div key={index} className="border-l-4 border-blue-500 pl-4 py-3 bg-blue-50 rounded-r-lg">
                    <h3 className="font-semibold text-lg mb-2">{layer.layer}</h3>
                    <p className="text-muted-foreground mb-3">{layer.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {layer.components.map((component, idx) => (
                        <Badge key={idx} variant="outline" className="bg-white">
                          {component}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Network className="h-5 w-5" />
                  Data Flow
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-blue-500 rounded-full" />
                    <span className="text-sm">Git webhook triggers pipeline</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full" />
                    <span className="text-sm">AutoBuild agent processes code</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full" />
                    <span className="text-sm">SecureGuard performs security scan</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-purple-500 rounded-full" />
                    <span className="text-sm">DeployMaster handles deployment</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full" />
                    <span className="text-sm">CostOptimizer monitors resources</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Cpu className="h-5 w-5" />
                  Performance Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">Average Build Time</span>
                    <span className="font-medium">3.2 minutes</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Deploy Success Rate</span>
                    <span className="font-medium">98.7%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Security Scan Time</span>
                    <span className="font-medium">45 seconds</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Cost Optimization</span>
                    <span className="font-medium">32% savings</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="features" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                  Implemented Features
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Multi-cloud deployment (AWS, GCP, Azure)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Intelligent CI/CD agents</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Real-time monitoring & alerts</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Security scanning & compliance</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Cost optimization & analytics</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Team collaboration & permissions</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Comprehensive audit trail</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-yellow-600" />
                  Future Enhancements
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-yellow-600" />
                    <span className="text-sm">Machine learning-based optimization</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-yellow-600" />
                    <span className="text-sm">Advanced compliance frameworks</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-yellow-600" />
                    <span className="text-sm">Custom workflow designer</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-yellow-600" />
                    <span className="text-sm">Mobile application support</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-yellow-600" />
                    <span className="text-sm">API rate limiting & throttling</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Alert>
            <FileText className="h-4 w-4" />
            <AlertDescription>
              <strong>Development Status:</strong> PipelineForge is a production-ready platform with 
              comprehensive CI/CD automation capabilities, multi-cloud support, and intelligent agent-based workflows.
            </AlertDescription>
          </Alert>
        </TabsContent>
      </Tabs>
    </div>
  );
}