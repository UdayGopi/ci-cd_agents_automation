import { TopBar } from "@/components/layout/topbar";
import { StatsOverview } from "@/components/dashboard/stats-overview";
import { RecentPipelines } from "@/components/dashboard/recent-pipelines";
import { AgentStatus } from "@/components/dashboard/agent-status";
import { ProjectsOverview } from "@/components/dashboard/projects-overview";
import { SecurityInsights } from "@/components/dashboard/security-insights";
import { CostAnalytics } from "@/components/dashboard/cost-analytics";

export default function Dashboard() {
  return (
    <div className="flex flex-col h-full">
      <TopBar 
        title="Dashboard" 
        subtitle="Monitor your CI/CD pipelines and deployments"
      />
      
      <div className="flex-1 p-6 space-y-6 overflow-auto">
        <StatsOverview />
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <RecentPipelines />
          <AgentStatus />
        </div>
        
        <ProjectsOverview />
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <SecurityInsights />
          <CostAnalytics />
        </div>
      </div>
    </div>
  );
}
