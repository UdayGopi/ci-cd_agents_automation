import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { TopBar } from "@/components/layout/topbar";
import { PipelineView } from "@/components/pipelines/pipeline-view";
import { Button } from "@/components/ui/button";
import { Play, Settings, GitBranch, Clock, CheckCircle2, XCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Project, Build } from "@/lib/types";

export default function ProjectDetail() {
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();
  
  const { data: project, isLoading: projectLoading } = useQuery<Project>({
    queryKey: ["/api/projects", id],
  });

  const { data: builds, isLoading: buildsLoading } = useQuery<Build[]>({
    queryKey: ["/api/builds", { projectId: id }],
  });

  const handleTriggerBuild = async () => {
    try {
      await apiRequest("POST", `/api/projects/${id}/build`, {});
      toast({
        title: "Build Triggered",
        description: "The build has been queued successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to trigger build",
        variant: "destructive",
      });
    }
  };

  if (projectLoading) {
    return (
      <div className="flex flex-col h-full">
        <TopBar title="Loading..." subtitle="Please wait..." />
        <div className="flex-1 p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-700 rounded w-1/3"></div>
            <div className="h-32 bg-gray-700 rounded"></div>
            <div className="h-64 bg-gray-700 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="flex flex-col h-full">
        <TopBar title="Project Not Found" subtitle="The requested project could not be found" />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <XCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-white mb-2">Project Not Found</h2>
            <p className="text-gray-400">The project you're looking for doesn't exist or has been deleted.</p>
          </div>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-600';
      case 'failed': return 'bg-red-600';
      case 'running': return 'bg-yellow-600';
      default: return 'bg-gray-600';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success': return <CheckCircle2 className="w-4 h-4" />;
      case 'failed': return <XCircle className="w-4 h-4" />;
      case 'running': return <Clock className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  return (
    <div className="flex flex-col h-full">
      <TopBar 
        title={project.name}
        subtitle={project.repositoryUrl}
        action={
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </Button>
            <Button onClick={handleTriggerBuild} className="bg-blue-600 hover:bg-blue-700">
              <Play className="w-4 h-4 mr-2" />
              Trigger Build
            </Button>
          </div>
        }
      />
      
      <div className="flex-1 p-6 overflow-auto space-y-6">
        {/* Project Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-gray-400">Deployment Target</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2">
                <Badge variant="outline" className="text-blue-400 border-blue-400">
                  {project.deploymentTarget.toUpperCase()}
                </Badge>
                <span className="text-white">{project.clusterName}</span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-gray-400">Branch</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2">
                <GitBranch className="w-4 h-4 text-gray-400" />
                <span className="text-white">{project.branch}</span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-gray-400">Project Type</CardTitle>
            </CardHeader>
            <CardContent>
              <Badge variant="outline" className="text-green-400 border-green-400">
                {project.projectType}
              </Badge>
            </CardContent>
          </Card>
        </div>

        {/* Build History */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Recent Builds</CardTitle>
          </CardHeader>
          <CardContent>
            {buildsLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="bg-gray-700 rounded-lg p-4 animate-pulse">
                    <div className="h-4 bg-gray-600 rounded w-1/3 mb-2"></div>
                    <div className="h-3 bg-gray-600 rounded w-2/3"></div>
                  </div>
                ))}
              </div>
            ) : builds?.length === 0 ? (
              <div className="text-center py-8">
                <div className="text-gray-400 text-lg mb-2">No builds yet</div>
                <p className="text-gray-500 mb-4">Trigger your first build to get started</p>
                <Button onClick={handleTriggerBuild} className="bg-blue-600 hover:bg-blue-700">
                  <Play className="w-4 h-4 mr-2" />
                  Trigger Build
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {builds?.slice(0, 5).map((build) => (
                  <div key={build.id} className="bg-gray-700 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${getStatusColor(build.status)}`}></div>
                        <span className="font-medium text-white">Build #{build.buildNumber}</span>
                        <Badge variant="outline" className="text-xs">
                          {build.commitHash.slice(0, 7)}
                        </Badge>
                      </div>
                      <div className="flex items-center space-x-2 text-gray-400">
                        {getStatusIcon(build.status)}
                        <span className="text-sm">{build.status}</span>
                      </div>
                    </div>
                    <div className="text-sm text-gray-400">
                      {build.branch} • {new Date(build.startedAt).toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
