import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, AlertTriangle, CheckCircle, XCircle, Eye, FileText, TrendingUp } from "lucide-react";

export default function Security() {
  const { data: complianceReports, isLoading: loadingReports } = useQuery({
    queryKey: ["/api/compliance"],
    queryFn: () => apiRequest("/api/compliance"),
  });

  const { data: securityStats, isLoading: loadingStats } = useQuery({
    queryKey: ["/api/stats"],
    queryFn: () => apiRequest("/api/stats"),
  });

  const mockVulnerabilities = [
    {
      id: 1,
      title: "SQL Injection in Login Form",
      severity: "critical",
      project: "E-commerce API",
      status: "open",
      discovered: "2025-01-10",
      description: "Potential SQL injection vulnerability in user authentication"
    },
    {
      id: 2,
      title: "Cross-Site Scripting (XSS)",
      severity: "high",
      project: "Dashboard Frontend",
      status: "resolved",
      discovered: "2025-01-08",
      description: "Reflected XSS vulnerability in search functionality"
    },
    {
      id: 3,
      title: "Weak Password Policy",
      severity: "medium",
      project: "User Management",
      status: "open",
      discovered: "2025-01-05",
      description: "Password complexity requirements are insufficient"
    },
    {
      id: 4,
      title: "Insecure Direct Object Reference",
      severity: "high",
      project: "File Storage API",
      status: "in_progress",
      discovered: "2025-01-03",
      description: "Users can access files belonging to other users"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open": return "destructive";
      case "resolved": return "default";
      case "in_progress": return "secondary";
      default: return "outline";
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical": return "bg-red-100 text-red-800 border-red-200";
      case "high": return "bg-orange-100 text-orange-800 border-orange-200";
      case "medium": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "low": return "bg-green-100 text-green-800 border-green-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Shield className="h-8 w-8 text-blue-600" />
            Security Dashboard
          </h1>
          <p className="text-muted-foreground">
            Monitor security vulnerabilities, compliance status, and risk assessment
          </p>
        </div>
        <Button>
          <Eye className="mr-2 h-4 w-4" />
          Run Security Scan
        </Button>
      </div>

      {/* Security Overview Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-red-200 bg-red-50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Critical Vulnerabilities</CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {securityStats?.securityStats?.criticalVulnerabilities || 2}
            </div>
            <p className="text-xs text-red-600">Require immediate attention</p>
          </CardContent>
        </Card>

        <Card className="border-orange-200 bg-orange-50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">High Priority Issues</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {securityStats?.securityStats?.highPriorityIssues || 7}
            </div>
            <p className="text-xs text-orange-600">Fix within 7 days</p>
          </CardContent>
        </Card>

        <Card className="border-green-200 bg-green-50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Security Score</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {securityStats?.securityStats?.securityScore || 'B+'}
            </div>
            <p className="text-xs text-green-600">Above average</p>
          </CardContent>
        </Card>

        <Card className="border-blue-200 bg-blue-50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Compliance Status</CardTitle>
            <FileText className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">85%</div>
            <p className="text-xs text-blue-600">Compliant projects</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="vulnerabilities" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="vulnerabilities">Vulnerabilities</TabsTrigger>
          <TabsTrigger value="compliance">Compliance</TabsTrigger>
          <TabsTrigger value="trends">Security Trends</TabsTrigger>
        </TabsList>

        <TabsContent value="vulnerabilities" className="space-y-4">
          <div className="grid gap-4">
            {mockVulnerabilities.map((vuln) => (
              <Card key={vuln.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{vuln.title}</CardTitle>
                    <div className="flex items-center gap-2">
                      <Badge className={getSeverityColor(vuln.severity)}>
                        {vuln.severity.toUpperCase()}
                      </Badge>
                      <Badge variant={getStatusColor(vuln.status)}>
                        {vuln.status.replace('_', ' ').toUpperCase()}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">{vuln.description}</p>
                    <div className="flex justify-between items-center text-xs text-muted-foreground">
                      <span>Project: {vuln.project}</span>
                      <span>Discovered: {vuln.discovered}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="compliance" className="space-y-4">
          <div className="grid gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Compliance Reports
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>SOC 2 Type II</span>
                    <Badge variant="default">Compliant</Badge>
                  </div>
                  <Progress value={92} className="h-2" />
                  <p className="text-sm text-muted-foreground">
                    92% of controls are compliant. Review remaining 8% for full compliance.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>GDPR Compliance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Data Protection Controls</span>
                    <Badge variant="secondary">In Progress</Badge>
                  </div>
                  <Progress value={78} className="h-2" />
                  <p className="text-sm text-muted-foreground">
                    78% compliant. Data retention policies need review.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>ISO 27001</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Information Security Management</span>
                    <Badge variant="default">Compliant</Badge>
                  </div>
                  <Progress value={95} className="h-2" />
                  <p className="text-sm text-muted-foreground">
                    95% compliant. Minor documentation updates required.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="trends" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Vulnerability Trends
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">This Month</span>
                    <span className="text-sm font-semibold">-15%</span>
                  </div>
                  <Progress value={85} className="h-2" />
                  <p className="text-sm text-muted-foreground">
                    15% reduction in vulnerabilities compared to last month
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Security Score History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Current Score</span>
                    <span className="text-sm font-semibold text-green-600">B+</span>
                  </div>
                  <Progress value={78} className="h-2" />
                  <p className="text-sm text-muted-foreground">
                    Improved from B- last quarter
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Security Recommendation:</strong> Enable automated security scanning 
              in your CI/CD pipeline to catch vulnerabilities early in the development process.
            </AlertDescription>
          </Alert>
        </TabsContent>
      </Tabs>
    </div>
  );
}