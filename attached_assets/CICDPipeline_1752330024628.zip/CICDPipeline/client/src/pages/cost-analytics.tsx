import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { DollarSign, TrendingDown, TrendingUp, Lightbulb, Cloud, Server, Database } from "lucide-react";

export default function CostAnalytics() {
  const { data: costStats, isLoading } = useQuery({
    queryKey: ["/api/stats"],
    queryFn: () => apiRequest("/api/stats"),
  });

  const mockCostBreakdown = [
    { service: "AWS ECS", cost: 245.50, percentage: 35, trend: "up" },
    { service: "AWS EKS", cost: 189.30, percentage: 27, trend: "down" },
    { service: "Azure AKS", cost: 156.20, percentage: 22, trend: "stable" },
    { service: "GCP Cloud Run", cost: 78.40, percentage: 11, trend: "up" },
    { service: "Container Registry", cost: 35.60, percentage: 5, trend: "stable" },
  ];

  const mockOptimizations = [
    {
      id: 1,
      title: "Switch to Spot Instances",
      description: "Use spot instances for non-critical workloads to reduce costs by up to 70%",
      potentialSavings: 180,
      effort: "Medium",
      impact: "High",
      priority: "high"
    },
    {
      id: 2,
      title: "Optimize Container Resources",
      description: "Right-size container CPU and memory allocations based on actual usage",
      potentialSavings: 95,
      effort: "Low",
      impact: "Medium",
      priority: "medium"
    },
    {
      id: 3,
      title: "Implement Auto-scaling",
      description: "Enable horizontal pod autoscaling to match capacity with demand",
      potentialSavings: 125,
      effort: "Medium",
      impact: "High",
      priority: "high"
    },
    {
      id: 4,
      title: "Reserved Instance Commitment",
      description: "Commit to reserved instances for predictable workloads",
      potentialSavings: 220,
      effort: "High",
      impact: "High",
      priority: "medium"
    }
  ];

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up": return <TrendingUp className="h-4 w-4 text-red-500" />;
      case "down": return <TrendingDown className="h-4 w-4 text-green-500" />;
      default: return <div className="h-4 w-4 bg-gray-400 rounded-full" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "destructive";
      case "medium": return "secondary";
      case "low": return "outline";
      default: return "default";
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <DollarSign className="h-8 w-8 text-green-600" />
            Cost Analytics
          </h1>
          <p className="text-muted-foreground">
            Monitor infrastructure costs, track spending trends, and optimize resource usage
          </p>
        </div>
        <Button>
          <Lightbulb className="mr-2 h-4 w-4" />
          Generate Report
        </Button>
      </div>

      {/* Cost Overview Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Cost</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">$705</div>
            <p className="text-xs text-blue-600">+12% from last month</p>
          </CardContent>
        </Card>

        <Card className="border-green-200 bg-green-50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Savings</CardTitle>
            <TrendingDown className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              ${costStats?.costStats?.monthlySavings || 89}
            </div>
            <p className="text-xs text-green-600">Through optimization</p>
          </CardContent>
        </Card>

        <Card className="border-purple-200 bg-purple-50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Resource Efficiency</CardTitle>
            <Server className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
              {costStats?.costStats?.resourceEfficiency || 87}%
            </div>
            <p className="text-xs text-purple-600">Above target</p>
          </CardContent>
        </Card>

        <Card className="border-orange-200 bg-orange-50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Optimization Opportunities</CardTitle>
            <Lightbulb className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {costStats?.costStats?.recommendations || 5}
            </div>
            <p className="text-xs text-orange-600">Potential savings</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="breakdown" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="breakdown">Cost Breakdown</TabsTrigger>
          <TabsTrigger value="optimization">Optimization</TabsTrigger>
          <TabsTrigger value="forecasting">Forecasting</TabsTrigger>
        </TabsList>

        <TabsContent value="breakdown" className="space-y-4">
          <div className="grid gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Cloud className="h-5 w-5" />
                  Service Cost Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockCostBreakdown.map((service, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{service.service}</span>
                          {getTrendIcon(service.trend)}
                        </div>
                        <div className="text-right">
                          <div className="font-bold">${service.cost}</div>
                          <div className="text-sm text-muted-foreground">{service.percentage}%</div>
                        </div>
                      </div>
                      <Progress value={service.percentage} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Top Cost Drivers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">Compute Resources</span>
                      <span className="font-semibold">$425</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Data Transfer</span>
                      <span className="font-semibold">$156</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Storage</span>
                      <span className="font-semibold">$89</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Load Balancing</span>
                      <span className="font-semibold">$35</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Cost by Environment</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">Production</span>
                      <span className="font-semibold">$485</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Staging</span>
                      <span className="font-semibold">$125</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Development</span>
                      <span className="font-semibold">$65</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Testing</span>
                      <span className="font-semibold">$30</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="optimization" className="space-y-4">
          <div className="grid gap-4">
            {mockOptimizations.map((opt) => (
              <Card key={opt.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{opt.title}</CardTitle>
                    <div className="flex items-center gap-2">
                      <Badge variant={getPriorityColor(opt.priority)}>
                        {opt.priority.toUpperCase()}
                      </Badge>
                      <Badge variant="outline" className="text-green-600 border-green-600">
                        ${opt.potentialSavings}/month
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground">{opt.description}</p>
                    <div className="flex justify-between items-center text-sm">
                      <div className="flex gap-4">
                        <span>Effort: <strong>{opt.effort}</strong></span>
                        <span>Impact: <strong>{opt.impact}</strong></span>
                      </div>
                      <Button size="sm" variant="outline">
                        Implement
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Alert>
            <Lightbulb className="h-4 w-4" />
            <AlertDescription>
              <strong>Cost Optimization Tip:</strong> Implementing all high-priority optimizations 
              could save up to $620 per month (88% cost reduction).
            </AlertDescription>
          </Alert>
        </TabsContent>

        <TabsContent value="forecasting" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Cost Projection
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Next Month</span>
                    <span className="font-semibold">$798</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Next Quarter</span>
                    <span className="font-semibold">$2,450</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Next Year</span>
                    <span className="font-semibold">$9,200</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Budget Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Current Usage</span>
                    <span className="font-semibold">$705 / $1,000</span>
                  </div>
                  <Progress value={70.5} className="h-2" />
                  <p className="text-sm text-muted-foreground">
                    70.5% of monthly budget used
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Cost Anomaly Detection</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Alert>
                  <TrendingUp className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Anomaly Detected:</strong> AWS ECS costs increased by 45% last week. 
                    This may be due to increased traffic or resource scaling.
                  </AlertDescription>
                </Alert>
                <Alert>
                  <Database className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Storage Alert:</strong> Database storage costs are trending upward. 
                    Consider implementing data archiving policies.
                  </AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}