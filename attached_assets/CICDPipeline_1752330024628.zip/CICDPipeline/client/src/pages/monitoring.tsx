import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Monitor, Activity, AlertTriangle, CheckCircle, Clock, Cpu, HardDrive, Network, Zap } from "lucide-react";

export default function Monitoring() {
  const [selectedProject, setSelectedProject] = useState<string>("all");
  const [timeRange, setTimeRange] = useState<string>("24h");

  const { data: projects } = useQuery({
    queryKey: ["/api/projects"],
    queryFn: () => apiRequest("/api/projects"),
  });

  const { data: agents } = useQuery({
    queryKey: ["/api/agents"],
    queryFn: () => apiRequest("/api/agents"),
  });

  const mockMetrics = [
    {
      id: 1,
      name: "CPU Usage",
      value: 68,
      status: "normal",
      icon: Cpu,
      color: "blue",
      unit: "%",
      trend: "stable"
    },
    {
      id: 2,
      name: "Memory Usage",
      value: 82,
      status: "warning",
      icon: HardDrive,
      color: "orange",
      unit: "%",
      trend: "increasing"
    },
    {
      id: 3,
      name: "Network I/O",
      value: 45,
      status: "normal",
      icon: Network,
      color: "green",
      unit: "MB/s",
      trend: "stable"
    },
    {
      id: 4,
      name: "Response Time",
      value: 156,
      status: "normal",
      icon: Clock,
      color: "purple",
      unit: "ms",
      trend: "decreasing"
    }
  ];

  const mockAlerts = [
    {
      id: 1,
      title: "High Memory Usage",
      description: "Memory usage above 80% threshold for E-commerce API",
      severity: "warning",
      timestamp: "2025-01-11T23:45:00Z",
      project: "E-commerce API",
      status: "active"
    },
    {
      id: 2,
      title: "Deployment Failed",
      description: "Deployment to production failed for Dashboard Frontend",
      severity: "critical",
      timestamp: "2025-01-11T23:30:00Z",
      project: "Dashboard Frontend",
      status: "resolved"
    },
    {
      id: 3,
      title: "SSL Certificate Expiring",
      description: "SSL certificate expires in 7 days",
      severity: "warning",
      timestamp: "2025-01-11T22:15:00Z",
      project: "API Gateway",
      status: "acknowledged"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "normal": return "bg-green-100 text-green-800 border-green-200";
      case "warning": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "critical": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical": return "destructive";
      case "warning": return "secondary";
      case "info": return "outline";
      default: return "default";
    }
  };

  const getProgressColor = (value: number) => {
    if (value > 80) return "bg-red-500";
    if (value > 60) return "bg-yellow-500";
    return "bg-green-500";
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Monitor className="h-8 w-8 text-purple-600" />
            System Monitoring
          </h1>
          <p className="text-muted-foreground">
            Real-time monitoring, alerts, and performance metrics for your infrastructure
          </p>
        </div>
        <div className="flex gap-2">
          <Select value={selectedProject} onValueChange={setSelectedProject}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Select project" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Projects</SelectItem>
              {projects?.map((project: any) => (
                <SelectItem key={project.id} value={project.id.toString()}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue placeholder="Time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1h">Last Hour</SelectItem>
              <SelectItem value="24h">Last 24 Hours</SelectItem>
              <SelectItem value="7d">Last 7 Days</SelectItem>
              <SelectItem value="30d">Last 30 Days</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* System Health Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {mockMetrics.map((metric) => {
          const Icon = metric.icon;
          return (
            <Card key={metric.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{metric.name}</CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold mb-2">
                  {metric.value}{metric.unit}
                </div>
                <div className="space-y-2">
                  <Progress 
                    value={metric.value} 
                    className="h-2"
                    color={getProgressColor(metric.value)}
                  />
                  <div className="flex justify-between items-center">
                    <Badge className={getStatusColor(metric.status)}>
                      {metric.status.toUpperCase()}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {metric.trend}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="agents">Agents</TabsTrigger>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
          <TabsTrigger value="logs">Logs</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  System Performance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Overall Health</span>
                    <Badge className="bg-green-100 text-green-800">Healthy</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Active Services</span>
                    <span className="font-semibold">12/12</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Avg Response Time</span>
                    <span className="font-semibold">145ms</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Uptime</span>
                    <span className="font-semibold">99.9%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Resource Utilization</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">CPU Clusters</span>
                      <span className="text-sm font-semibold">68%</span>
                    </div>
                    <Progress value={68} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Memory</span>
                      <span className="text-sm font-semibold">82%</span>
                    </div>
                    <Progress value={82} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Storage</span>
                      <span className="text-sm font-semibold">45%</span>
                    </div>
                    <Progress value={45} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span className="text-sm">Deployment successful: E-commerce API v2.1.0</span>
                  <span className="text-xs text-muted-foreground ml-auto">2 minutes ago</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full" />
                  <span className="text-sm">Auto-scaling triggered: Frontend cluster +2 instances</span>
                  <span className="text-xs text-muted-foreground ml-auto">15 minutes ago</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full" />
                  <span className="text-sm">Security scan completed: 3 vulnerabilities found</span>
                  <span className="text-xs text-muted-foreground ml-auto">1 hour ago</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-purple-500 rounded-full" />
                  <span className="text-sm">Cost optimization: $45 saved this month</span>
                  <span className="text-xs text-muted-foreground ml-auto">3 hours ago</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="agents" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {agents?.map((agent: any) => (
              <Card key={agent.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{agent.name}</CardTitle>
                    <Badge variant={agent.status === 'active' ? 'default' : 'secondary'}>
                      {agent.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground">{agent.description}</p>
                    <div className="flex justify-between items-center text-sm">
                      <span>Last Active:</span>
                      <span className="font-medium">
                        {agent.lastHeartbeat ? new Date(agent.lastHeartbeat).toLocaleString() : 'Never'}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span>Tasks Completed:</span>
                      <span className="font-medium">{agent.tasksCompleted || 0}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span>Success Rate:</span>
                      <span className="font-medium">{agent.successRate || 0}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <div className="grid gap-4">
            {mockAlerts.map((alert) => (
              <Card key={alert.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5 text-yellow-500" />
                      {alert.title}
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <Badge variant={getSeverityColor(alert.severity)}>
                        {alert.severity.toUpperCase()}
                      </Badge>
                      <Badge variant="outline">
                        {alert.status}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">{alert.description}</p>
                    <div className="flex justify-between items-center text-xs text-muted-foreground">
                      <span>Project: {alert.project}</span>
                      <span>Time: {new Date(alert.timestamp).toLocaleString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Alert>
            <Zap className="h-4 w-4" />
            <AlertDescription>
              <strong>Alert Configuration:</strong> You have 3 active alerts and 2 resolved alerts in the last 24 hours.
              Configure notification preferences in Settings to receive real-time alerts.
            </AlertDescription>
          </Alert>
        </TabsContent>

        <TabsContent value="logs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>System Logs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 font-mono text-sm bg-gray-50 p-4 rounded-lg max-h-96 overflow-y-auto">
                <div className="text-green-600">[2025-01-11 23:58:15] INFO: Deployment pipeline started for project: E-commerce API</div>
                <div className="text-blue-600">[2025-01-11 23:58:10] DEBUG: Docker image build completed successfully</div>
                <div className="text-green-600">[2025-01-11 23:58:05] INFO: Security scan passed with 0 critical vulnerabilities</div>
                <div className="text-yellow-600">[2025-01-11 23:57:58] WARN: Memory usage threshold exceeded on instance i-0123456789</div>
                <div className="text-green-600">[2025-01-11 23:57:45] INFO: Auto-scaling triggered: added 2 instances to cluster</div>
                <div className="text-blue-600">[2025-01-11 23:57:30] DEBUG: Health check passed for all services</div>
                <div className="text-green-600">[2025-01-11 23:57:15] INFO: Cost optimization completed: $12 saved</div>
                <div className="text-red-600">[2025-01-11 23:56:45] ERROR: Failed to connect to database (retrying...)</div>
                <div className="text-green-600">[2025-01-11 23:56:30] INFO: Database connection restored</div>
                <div className="text-blue-600">[2025-01-11 23:56:15] DEBUG: Webhook received from GitHub: push event</div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}