import { useQuery } from "@tanstack/react-query";
import { TopBar } from "@/components/layout/topbar";
import { PipelineView } from "@/components/pipelines/pipeline-view";
import type { Build } from "@/lib/types";

export default function Pipelines() {
  const { data: builds, isLoading } = useQuery<Build[]>({
    queryKey: ["/api/builds"],
  });

  return (
    <div className="flex flex-col h-full">
      <TopBar 
        title="Pipelines" 
        subtitle="View and manage your CI/CD pipeline executions"
      />
      
      <div className="flex-1 p-6 overflow-auto">
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="bg-gray-800 rounded-lg p-6 animate-pulse">
                <div className="h-4 bg-gray-700 rounded w-1/3 mb-2"></div>
                <div className="h-3 bg-gray-700 rounded w-2/3 mb-4"></div>
                <div className="h-8 bg-gray-700 rounded w-full"></div>
              </div>
            ))}
          </div>
        ) : builds?.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-400 text-lg mb-4">No pipeline runs yet</div>
            <p className="text-gray-500">Pipeline runs will appear here once you trigger builds</p>
          </div>
        ) : (
          <div className="space-y-4">
            {builds?.map((build) => (
              <PipelineView key={build.id} build={build} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
