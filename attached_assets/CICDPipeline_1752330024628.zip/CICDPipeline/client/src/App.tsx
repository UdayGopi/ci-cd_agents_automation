import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/dashboard";
import Projects from "@/pages/projects";
import Pipelines from "@/pages/pipelines";
import ProjectDetail from "@/pages/project-detail";
import Security from "@/pages/security";
import CostAnalytics from "@/pages/cost-analytics";
import Monitoring from "@/pages/monitoring";
import Teams from "@/pages/teams";
import Settings from "@/pages/settings";
import TechOverview from "@/pages/tech-overview";
import NotFound from "@/pages/not-found";
import { Sidebar } from "@/components/layout/sidebar";

function Router() {
  return (
    <div className="flex h-screen overflow-hidden bg-gray-900">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/projects" component={Projects} />
          <Route path="/projects/:id" component={ProjectDetail} />
          <Route path="/pipelines" component={Pipelines} />
          <Route path="/security" component={Security} />
          <Route path="/cost-analytics" component={CostAnalytics} />
          <Route path="/monitoring" component={Monitoring} />
          <Route path="/teams" component={Teams} />
          <Route path="/settings" component={Settings} />
          <Route path="/tech-overview" component={TechOverview} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
