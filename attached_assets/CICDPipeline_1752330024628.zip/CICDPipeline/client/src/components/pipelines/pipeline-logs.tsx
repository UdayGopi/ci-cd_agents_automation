import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Download, Search, Filter } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useWebSocket } from "@/hooks/use-websocket";
import type { Build } from "@/lib/types";

interface PipelineLogsProps {
  buildId: number;
}

export function PipelineLogs({ buildId }: PipelineLogsProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedLevel, setSelectedLevel] = useState("all");
  const [logs, setLogs] = useState<string[]>([]);

  const { data: build } = useQuery<Build>({
    queryKey: ["/api/builds", buildId],
  });

  const { lastMessage } = useWebSocket();

  useEffect(() => {
    if (lastMessage && lastMessage.type === 'build_logs' && lastMessage.data.buildId === buildId) {
      setLogs(prev => [...prev, lastMessage.data.log]);
    }
  }, [lastMessage, buildId]);

  // Parse build logs if available
  useEffect(() => {
    if (build?.buildLogs) {
      setLogs(build.buildLogs.split('\n').filter(log => log.trim()));
    }
  }, [build]);

  const parseLogLevel = (log: string) => {
    if (log.includes('[ERROR]') || log.includes('ERROR:')) return 'error';
    if (log.includes('[WARN]') || log.includes('WARN:')) return 'warning';
    if (log.includes('[INFO]') || log.includes('INFO:')) return 'info';
    if (log.includes('[DEBUG]') || log.includes('DEBUG:')) return 'debug';
    return 'info';
  };

  const getLogColor = (level: string) => {
    switch (level) {
      case 'error': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      case 'info': return 'text-green-400';
      case 'debug': return 'text-gray-400';
      default: return 'text-white';
    }
  };

  const filteredLogs = logs.filter(log => {
    const matchesSearch = !searchTerm || log.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLevel = selectedLevel === 'all' || parseLogLevel(log) === selectedLevel;
    return matchesSearch && matchesLevel;
  });

  const mockStages = [
    { name: 'Checkout', logs: ['Cloning repository...', 'Checked out commit abc123', 'Repository cloned successfully'] },
    { name: 'Dependencies', logs: ['Installing dependencies...', 'npm install completed', 'Dependencies installed'] },
    { name: 'Lint', logs: ['Running ESLint...', 'No linting errors found', 'Linting completed'] },
    { name: 'Test', logs: ['Running tests...', 'All tests passed', 'Test coverage: 87%'] },
    { name: 'Build', logs: ['Building application...', 'Build completed successfully', 'Assets generated'] },
    { name: 'Deploy', logs: ['Deploying to AWS...', 'Deployment successful', 'Health check passed'] },
  ];

  const downloadLogs = () => {
    const logContent = logs.join('\n');
    const blob = new Blob([logContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `build-${buildId}-logs.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex items-center space-x-4">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="Search logs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-gray-700 border-gray-600 text-white"
          />
        </div>
        <select
          value={selectedLevel}
          onChange={(e) => setSelectedLevel(e.target.value)}
          className="bg-gray-700 border-gray-600 text-white rounded-lg px-3 py-2"
        >
          <option value="all">All Levels</option>
          <option value="error">Error</option>
          <option value="warning">Warning</option>
          <option value="info">Info</option>
          <option value="debug">Debug</option>
        </select>
        <Button
          onClick={downloadLogs}
          variant="outline"
          size="sm"
          className="border-gray-600 hover:bg-gray-700"
        >
          <Download className="w-4 h-4 mr-2" />
          Download
        </Button>
      </div>

      <Tabs defaultValue="combined" className="w-full">
        <TabsList className="grid w-full grid-cols-7 bg-gray-700">
          <TabsTrigger value="combined">Combined</TabsTrigger>
          {mockStages.map((stage) => (
            <TabsTrigger key={stage.name} value={stage.name.toLowerCase()}>
              {stage.name}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="combined" className="mt-4">
          <Card className="bg-gray-900 border-gray-700">
            <CardContent className="p-0">
              <ScrollArea className="h-96">
                <div className="p-4 font-mono text-sm">
                  {filteredLogs.length === 0 ? (
                    <div className="text-center text-gray-400 py-8">
                      {logs.length === 0 ? 'No logs available yet' : 'No logs match your filters'}
                    </div>
                  ) : (
                    filteredLogs.map((log, index) => {
                      const level = parseLogLevel(log);
                      return (
                        <div key={index} className="flex items-start space-x-2 py-1 hover:bg-gray-800">
                          <Badge variant="outline" className={`text-xs ${getLogColor(level)} border-current`}>
                            {level}
                          </Badge>
                          <span className="text-gray-300 text-xs">
                            {new Date().toLocaleTimeString()}
                          </span>
                          <span className={`flex-1 ${getLogColor(level)}`}>
                            {log}
                          </span>
                        </div>
                      );
                    })
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {mockStages.map((stage) => (
          <TabsContent key={stage.name} value={stage.name.toLowerCase()} className="mt-4">
            <Card className="bg-gray-900 border-gray-700">
              <CardContent className="p-0">
                <ScrollArea className="h-96">
                  <div className="p-4 font-mono text-sm">
                    {stage.logs.map((log, index) => (
                      <div key={index} className="flex items-start space-x-2 py-1 hover:bg-gray-800">
                        <Badge variant="outline" className="text-xs text-green-400 border-green-400">
                          info
                        </Badge>
                        <span className="text-gray-300 text-xs">
                          {new Date().toLocaleTimeString()}
                        </span>
                        <span className="flex-1 text-green-400">
                          {log}
                        </span>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
