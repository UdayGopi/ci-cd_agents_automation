import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Progress } from "@/components/ui/progress";
import { 
  GitBranch, 
  User, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle,
  ChevronDown,
  ChevronRight,
  Play,
  Pause,
  RotateCcw,
  ExternalLink
} from "lucide-react";
import { PipelineLogs } from "./pipeline-logs";
import type { Build } from "@/lib/types";

interface PipelineViewProps {
  build: Build;
  detailed?: boolean;
}

export function PipelineView({ build, detailed = false }: PipelineViewProps) {
  const [isExpanded, setIsExpanded] = useState(detailed);
  const [showLogs, setShowLogs] = useState(false);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success': return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'failed': return <XCircle className="w-5 h-5 text-red-500" />;
      case 'running': return <Clock className="w-5 h-5 text-yellow-500 animate-pulse" />;
      case 'pending': return <AlertCircle className="w-5 h-5 text-gray-500" />;
      default: return <AlertCircle className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'text-green-400 border-green-400';
      case 'failed': return 'text-red-400 border-red-400';
      case 'running': return 'text-yellow-400 border-yellow-400';
      case 'pending': return 'text-gray-400 border-gray-400';
      default: return 'text-gray-400 border-gray-400';
    }
  };

  const getProgress = (status: string) => {
    switch (status) {
      case 'success': return 100;
      case 'failed': return 50;
      case 'running': return 60;
      case 'pending': return 0;
      default: return 0;
    }
  };

  const formatDuration = (duration: number | null) => {
    if (!duration) return 'N/A';
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    return `${minutes}m ${seconds}s`;
  };

  const pipelineStages = [
    { name: 'Checkout', status: build.status === 'pending' ? 'pending' : 'success' },
    { name: 'Dependencies', status: build.status === 'pending' ? 'pending' : 'success' },
    { name: 'Lint', status: build.status === 'pending' ? 'pending' : 'success' },
    { name: 'Test', status: build.status === 'pending' ? 'pending' : build.status === 'failed' ? 'failed' : 'success' },
    { name: 'Build', status: build.status === 'running' ? 'running' : build.status === 'success' ? 'success' : 'pending' },
    { name: 'Deploy', status: build.status === 'success' ? 'success' : 'pending' },
  ];

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" size="sm">
                  {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                </Button>
              </CollapsibleTrigger>
            </Collapsible>
            
            <div className="flex items-center space-x-3">
              {getStatusIcon(build.status)}
              <div>
                <CardTitle className="text-lg text-white">
                  Build #{build.buildNumber}
                </CardTitle>
                <div className="flex items-center space-x-2 text-sm text-gray-400">
                  <GitBranch className="w-4 h-4" />
                  <span>{build.branch}</span>
                  <span>•</span>
                  <span>{build.commitHash.slice(0, 7)}</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <Badge variant="outline" className={getStatusColor(build.status)}>
              {build.status}
            </Badge>
            <div className="text-sm text-gray-400">
              {new Date(build.startedAt).toLocaleString()}
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        {/* Progress Bar */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-400">Pipeline Progress</span>
            <span className="text-sm text-gray-400">{getProgress(build.status)}%</span>
          </div>
          <Progress value={getProgress(build.status)} className="h-2" />
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div className="text-center">
            <div className="text-lg font-semibold text-white">
              {formatDuration(build.duration)}
            </div>
            <div className="text-xs text-gray-400">Duration</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-semibold text-white">
              {build.testResults?.total || 0}
            </div>
            <div className="text-xs text-gray-400">Tests</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-semibold text-white">
              {build.testResults?.coverage || 0}%
            </div>
            <div className="text-xs text-gray-400">Coverage</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-semibold text-white">
              {build.securityScanResults?.critical || 0}
            </div>
            <div className="text-xs text-gray-400">Critical Issues</div>
          </div>
        </div>

        <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
          <CollapsibleContent className="space-y-4">
            {/* Pipeline Stages */}
            <div className="border-t border-gray-700 pt-4">
              <h4 className="text-sm font-medium text-white mb-3">Pipeline Stages</h4>
              <div className="space-y-2">
                {pipelineStages.map((stage, index) => (
                  <div key={stage.name} className="flex items-center space-x-3 p-3 bg-gray-700 rounded-lg">
                    <div className="flex-shrink-0">
                      {getStatusIcon(stage.status)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-white font-medium">{stage.name}</span>
                        <Badge variant="outline" className={getStatusColor(stage.status)}>
                          {stage.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Test Results */}
            {build.testResults && (
              <div className="border-t border-gray-700 pt-4">
                <h4 className="text-sm font-medium text-white mb-3">Test Results</h4>
                <div className="bg-gray-700 rounded-lg p-4">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-green-500">{build.testResults.passed}</div>
                      <div className="text-xs text-gray-400">Passed</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-red-500">{build.testResults.failed}</div>
                      <div className="text-xs text-gray-400">Failed</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-blue-500">{build.testResults.total}</div>
                      <div className="text-xs text-gray-400">Total</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Security Scan Results */}
            {build.securityScanResults && (
              <div className="border-t border-gray-700 pt-4">
                <h4 className="text-sm font-medium text-white mb-3">Security Scan</h4>
                <div className="bg-gray-700 rounded-lg p-4">
                  <div className="grid grid-cols-4 gap-4 text-center">
                    <div>
                      <div className="text-xl font-bold text-red-500">{build.securityScanResults.critical}</div>
                      <div className="text-xs text-gray-400">Critical</div>
                    </div>
                    <div>
                      <div className="text-xl font-bold text-orange-500">{build.securityScanResults.high}</div>
                      <div className="text-xs text-gray-400">High</div>
                    </div>
                    <div>
                      <div className="text-xl font-bold text-yellow-500">{build.securityScanResults.medium}</div>
                      <div className="text-xs text-gray-400">Medium</div>
                    </div>
                    <div>
                      <div className="text-xl font-bold text-blue-500">{build.securityScanResults.low}</div>
                      <div className="text-xs text-gray-400">Low</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="border-t border-gray-700 pt-4">
              <div className="flex items-center space-x-2">
                <Button
                  onClick={() => setShowLogs(!showLogs)}
                  variant="outline"
                  size="sm"
                  className="border-gray-600 hover:bg-gray-700"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  View Logs
                </Button>
                {build.status === 'running' && (
                  <Button variant="outline" size="sm" className="border-gray-600 hover:bg-gray-700">
                    <Pause className="w-4 h-4 mr-2" />
                    Cancel
                  </Button>
                )}
                {build.status === 'failed' && (
                  <Button variant="outline" size="sm" className="border-gray-600 hover:bg-gray-700">
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Retry
                  </Button>
                )}
              </div>
            </div>
          </CollapsibleContent>
        </Collapsible>

        {/* Logs Modal */}
        {showLogs && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-gray-800 rounded-lg w-full max-w-4xl max-h-[80vh] overflow-hidden">
              <div className="p-4 border-b border-gray-700">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-white">Build Logs - #{build.buildNumber}</h3>
                  <Button variant="ghost" size="sm" onClick={() => setShowLogs(false)}>
                    <XCircle className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div className="p-4 overflow-auto max-h-[60vh]">
                <PipelineLogs buildId={build.id} />
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
