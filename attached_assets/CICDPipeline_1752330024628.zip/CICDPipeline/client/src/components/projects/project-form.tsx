import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { X } from "lucide-react";

const projectSchema = z.object({
  name: z.string().min(1, "Project name is required"),
  repositoryUrl: z.string().url("Invalid repository URL"),
  branch: z.string().min(1, "Branch is required"),
  projectType: z.enum(["auto", "nodejs", "python", "java", "go", "docker"]),
  deploymentTarget: z.enum(["ecs", "eks"]),
  clusterName: z.string().min(1, "Cluster name is required"),
  serviceName: z.string().min(1, "Service name is required"),
  environmentVariables: z.string().optional(),
});

type ProjectFormData = z.infer<typeof projectSchema>;

interface ProjectFormProps {
  onClose: () => void;
}

export function ProjectForm({ onClose }: ProjectFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<ProjectFormData>({
    resolver: zodResolver(projectSchema),
    defaultValues: {
      name: "",
      repositoryUrl: "",
      branch: "main",
      projectType: "auto",
      deploymentTarget: "ecs",
      clusterName: "",
      serviceName: "",
      environmentVariables: "",
    },
  });

  const createProject = useMutation({
    mutationFn: async (data: ProjectFormData) => {
      const envVars = data.environmentVariables
        ? Object.fromEntries(
            data.environmentVariables
              .split('\n')
              .map(line => line.split('='))
              .filter(([key, value]) => key && value)
          )
        : {};

      return apiRequest("POST", "/api/projects", {
        ...data,
        environmentVariables: envVars,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "Success",
        description: "Project created successfully",
      });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create project",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: ProjectFormData) => {
    setIsSubmitting(true);
    await createProject.mutateAsync(data);
    setIsSubmitting(false);
  };

  return (
    <div className="max-h-[90vh] overflow-y-auto">
      <div className="p-6 border-b border-gray-700">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-semibold text-white">Create New Project</h3>
            <p className="text-gray-400 text-sm mt-1">Set up automated CI/CD for your repository</p>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <form onSubmit={form.handleSubmit(onSubmit)} className="p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="name" className="text-white">Project Name</Label>
            <Input
              id="name"
              {...form.register("name")}
              className="bg-gray-700 border-gray-600 text-white"
              placeholder="My Awesome Project"
            />
            {form.formState.errors.name && (
              <p className="text-red-400 text-sm mt-1">{form.formState.errors.name.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="repositoryUrl" className="text-white">Repository URL</Label>
            <Input
              id="repositoryUrl"
              {...form.register("repositoryUrl")}
              className="bg-gray-700 border-gray-600 text-white"
              placeholder="https://github.com/username/repo"
            />
            {form.formState.errors.repositoryUrl && (
              <p className="text-red-400 text-sm mt-1">{form.formState.errors.repositoryUrl.message}</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="branch" className="text-white">Branch</Label>
            <Input
              id="branch"
              {...form.register("branch")}
              className="bg-gray-700 border-gray-600 text-white"
              placeholder="main"
            />
            {form.formState.errors.branch && (
              <p className="text-red-400 text-sm mt-1">{form.formState.errors.branch.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="projectType" className="text-white">Project Type</Label>
            <Select onValueChange={(value) => form.setValue("projectType", value as any)}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Select project type" />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                <SelectItem value="auto">Auto-detect</SelectItem>
                <SelectItem value="nodejs">Node.js</SelectItem>
                <SelectItem value="python">Python</SelectItem>
                <SelectItem value="java">Java</SelectItem>
                <SelectItem value="go">Go</SelectItem>
                <SelectItem value="docker">Docker</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Label className="text-white">Deployment Target</Label>
          <RadioGroup
            defaultValue="ecs"
            onValueChange={(value) => form.setValue("deploymentTarget", value as any)}
            className="mt-2"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="bg-gray-700 border-gray-600 cursor-pointer hover:bg-gray-600">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <RadioGroupItem value="ecs" id="ecs" />
                    <div>
                      <Label htmlFor="ecs" className="font-medium text-white cursor-pointer">AWS ECS</Label>
                      <p className="text-sm text-gray-400">Container orchestration</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-700 border-gray-600 cursor-pointer hover:bg-gray-600">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <RadioGroupItem value="eks" id="eks" />
                    <div>
                      <Label htmlFor="eks" className="font-medium text-white cursor-pointer">AWS EKS</Label>
                      <p className="text-sm text-gray-400">Kubernetes cluster</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </RadioGroup>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="clusterName" className="text-white">Cluster Name</Label>
            <Input
              id="clusterName"
              {...form.register("clusterName")}
              className="bg-gray-700 border-gray-600 text-white"
              placeholder="production-cluster"
            />
            {form.formState.errors.clusterName && (
              <p className="text-red-400 text-sm mt-1">{form.formState.errors.clusterName.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="serviceName" className="text-white">Service Name</Label>
            <Input
              id="serviceName"
              {...form.register("serviceName")}
              className="bg-gray-700 border-gray-600 text-white"
              placeholder="my-service"
            />
            {form.formState.errors.serviceName && (
              <p className="text-red-400 text-sm mt-1">{form.formState.errors.serviceName.message}</p>
            )}
          </div>
        </div>

        <div>
          <Label htmlFor="environmentVariables" className="text-white">Environment Variables</Label>
          <Textarea
            id="environmentVariables"
            {...form.register("environmentVariables")}
            className="bg-gray-700 border-gray-600 text-white"
            rows={3}
            placeholder="NODE_ENV=production&#10;API_KEY=your-api-key"
          />
          <p className="text-gray-400 text-sm mt-1">One per line in KEY=VALUE format</p>
        </div>

        <div className="flex items-center justify-end space-x-4 pt-4">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            type="submit" 
            disabled={isSubmitting}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {isSubmitting ? "Creating..." : "Create Project"}
          </Button>
        </div>
      </form>
    </div>
  );
}
