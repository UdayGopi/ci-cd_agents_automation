import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GitBranch, Clock } from "lucide-react";
import type { Build } from "@/lib/types";

export function RecentPipelines() {
  const { data: builds, isLoading } = useQuery<Build[]>({
    queryKey: ["/api/builds/recent", 5],
  });

  if (isLoading) {
    return (
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Recent Pipeline Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-gray-700 rounded-lg p-4 animate-pulse">
                <div className="h-4 bg-gray-600 rounded w-1/3 mb-2"></div>
                <div className="h-3 bg-gray-600 rounded w-2/3 mb-2"></div>
                <div className="h-3 bg-gray-600 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-500';
      case 'failed': return 'bg-red-500';
      case 'running': return 'bg-yellow-500 animate-pulse';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'success': return { ci: 'Passed', cd: 'Deployed' };
      case 'failed': return { ci: 'Failed', cd: 'Cancelled' };
      case 'running': return { ci: 'Running', cd: 'Pending' };
      default: return { ci: 'Pending', cd: 'Pending' };
    }
  };

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white">Recent Pipeline Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {builds?.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-gray-400 mb-2">No recent pipeline activity</div>
              <p className="text-gray-500 text-sm">Pipeline runs will appear here</p>
            </div>
          ) : (
            builds?.map((build) => {
              const statusText = getStatusText(build.status);
              
              return (
                <div key={build.id} className="flex items-center space-x-4 p-4 bg-gray-700 rounded-lg">
                  <div className={`w-3 h-3 rounded-full ${getStatusColor(build.status)}`}></div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-white">Build #{build.buildNumber}</p>
                      <span className="text-xs text-gray-400">
                        {new Date(build.startedAt).toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-gray-400 mt-1">
                      <GitBranch className="w-3 h-3" />
                      <span>{build.branch}</span>
                      <span>•</span>
                      <span>{build.commitHash.slice(0, 7)}</span>
                    </div>
                    <div className="mt-2 flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <div className={`w-2 h-2 rounded-full ${build.status === 'success' ? 'bg-green-500' : build.status === 'failed' ? 'bg-red-500' : 'bg-yellow-500'}`}></div>
                        <span className="text-xs text-gray-400">CI: {statusText.ci}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className={`w-2 h-2 rounded-full ${build.status === 'success' ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                        <span className="text-xs text-gray-400">CD: {statusText.cd}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </CardContent>
    </Card>
  );
}
