import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PiggyBank, BarChart3, Lightbulb } from "lucide-react";

interface CostStats {
  costStats: {
    monthlySavings: number;
    resourceEfficiency: number;
    recommendations: number;
  };
}

export function CostAnalytics() {
  const { data: stats, isLoading } = useQuery<CostStats>({
    queryKey: ["/api/stats"],
  });

  if (isLoading) {
    return (
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Cost Optimization</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-gray-700 rounded-lg p-4 animate-pulse">
                <div className="h-4 bg-gray-600 rounded w-1/2 mb-2"></div>
                <div className="h-3 bg-gray-600 rounded w-2/3"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const costStats = stats?.costStats || {
    monthlySavings: 0,
    resourceEfficiency: 0,
    recommendations: 0
  };

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white">Cost Optimization</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-green-600 bg-opacity-20 rounded-lg flex items-center justify-center">
                <PiggyBank className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="font-medium text-white">Monthly Savings</p>
                <p className="text-sm text-gray-400">Optimized this month</p>
              </div>
            </div>
            <span className="text-2xl font-bold text-green-500">${costStats.monthlySavings}</span>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-yellow-600 bg-opacity-20 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-5 h-5 text-yellow-600" />
              </div>
              <div>
                <p className="font-medium text-white">Resource Efficiency</p>
                <p className="text-sm text-gray-400">CPU/Memory utilization</p>
              </div>
            </div>
            <span className="text-2xl font-bold text-yellow-500">{costStats.resourceEfficiency}%</span>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 bg-opacity-20 rounded-lg flex items-center justify-center">
                <Lightbulb className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-white">Recommendations</p>
                <p className="text-sm text-gray-400">Optimization suggestions</p>
              </div>
            </div>
            <span className="text-2xl font-bold text-blue-500">{costStats.recommendations}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
