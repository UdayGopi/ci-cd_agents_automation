import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, AlertCircle, Shield } from "lucide-react";

interface SecurityStats {
  securityStats: {
    criticalVulnerabilities: number;
    highPriorityIssues: number;
    securityScore: string;
  };
}

export function SecurityInsights() {
  const { data: stats, isLoading } = useQuery<SecurityStats>({
    queryKey: ["/api/stats"],
  });

  if (isLoading) {
    return (
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Security Insights</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-gray-700 rounded-lg p-4 animate-pulse">
                <div className="h-4 bg-gray-600 rounded w-1/2 mb-2"></div>
                <div className="h-3 bg-gray-600 rounded w-2/3"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const securityStats = stats?.securityStats || {
    criticalVulnerabilities: 0,
    highPriorityIssues: 0,
    securityScore: 'N/A'
  };

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white">Security Insights</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-red-600 bg-opacity-20 rounded-lg flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <p className="font-medium text-white">Critical Vulnerabilities</p>
                <p className="text-sm text-gray-400">Requires immediate attention</p>
              </div>
            </div>
            <span className="text-2xl font-bold text-red-500">{securityStats.criticalVulnerabilities}</span>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-yellow-600 bg-opacity-20 rounded-lg flex items-center justify-center">
                <AlertCircle className="w-5 h-5 text-yellow-600" />
              </div>
              <div>
                <p className="font-medium text-white">High Priority</p>
                <p className="text-sm text-gray-400">Should be addressed soon</p>
              </div>
            </div>
            <span className="text-2xl font-bold text-yellow-500">{securityStats.highPriorityIssues}</span>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-green-600 bg-opacity-20 rounded-lg flex items-center justify-center">
                <Shield className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="font-medium text-white">Security Score</p>
                <p className="text-sm text-gray-400">Overall security rating</p>
              </div>
            </div>
            <span className="text-2xl font-bold text-green-500">{securityStats.securityScore}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
