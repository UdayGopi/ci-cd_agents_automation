import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bot, Rocket, Shield, TrendingUp } from "lucide-react";
import type { Agent } from "@/lib/types";

export function AgentStatus() {
  const { data: agents, isLoading } = useQuery<Agent[]>({
    queryKey: ["/api/agents"],
  });

  if (isLoading) {
    return (
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Intelligent Agents</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-gray-700 rounded-lg p-4 animate-pulse">
                <div className="h-4 bg-gray-600 rounded w-1/2 mb-2"></div>
                <div className="h-3 bg-gray-600 rounded w-2/3"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getAgentIcon = (type: string) => {
    switch (type) {
      case 'autobuild': return <Bot className="w-5 h-5 text-blue-600" />;
      case 'deploymaster': return <Rocket className="w-5 h-5 text-green-600" />;
      case 'secureguard': return <Shield className="w-5 h-5 text-yellow-600" />;
      case 'costoptimizer': return <TrendingUp className="w-5 h-5 text-green-600" />;
      default: return <Bot className="w-5 h-5 text-gray-600" />;
    }
  };

  const getAgentDescription = (type: string) => {
    switch (type) {
      case 'autobuild': return 'CI Pipeline Automation';
      case 'deploymaster': return 'CD Pipeline Automation';
      case 'secureguard': return 'Security Scanning';
      case 'costoptimizer': return 'Resource Optimization';
      default: return 'Agent';
    }
  };

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white">Intelligent Agents</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {agents?.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-gray-400 mb-2">No agents configured</div>
              <p className="text-gray-500 text-sm">Agents will appear here once configured</p>
            </div>
          ) : (
            agents?.map((agent) => (
              <div key={agent.id} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gray-600 bg-opacity-50 rounded-lg flex items-center justify-center">
                    {getAgentIcon(agent.type)}
                  </div>
                  <div>
                    <p className="font-medium text-white">{agent.name}</p>
                    <p className="text-sm text-gray-400">{getAgentDescription(agent.type)}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${agent.status === 'active' ? 'bg-green-500' : 'bg-red-500'}`}></div>
                  <Badge variant="outline" className={agent.status === 'active' ? 'text-green-400 border-green-400' : 'text-red-400 border-red-400'}>
                    {agent.status}
                  </Badge>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
