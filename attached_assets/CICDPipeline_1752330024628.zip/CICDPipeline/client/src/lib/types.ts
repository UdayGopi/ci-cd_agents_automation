export interface User {
  id: number;
  username: string;
  email?: string;
  createdAt: string;
}

export interface Project {
  id: number;
  name: string;
  repositoryUrl: string;
  branch: string;
  projectType: 'auto' | 'nodejs' | 'python' | 'java' | 'go' | 'docker';
  deploymentTarget: 'ecs' | 'eks';
  clusterName: string;
  serviceName: string;
  environmentVariables?: Record<string, string>;
  awsCredentials?: Record<string, string>;
  webhookSecret?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Build {
  id: number;
  projectId: number;
  buildNumber: number;
  commitHash: string;
  branch: string;
  status: 'pending' | 'running' | 'success' | 'failed' | 'cancelled';
  dockerImageUrl?: string;
  buildLogs?: string;
  testResults?: {
    total: number;
    passed: number;
    failed: number;
    coverage: number;
  };
  securityScanResults?: {
    critical: number;
    high: number;
    medium: number;
    low: number;
    vulnerabilities: Array<{
      severity: string;
      title: string;
      description: string;
      solution: string;
    }>;
  };
  costMetrics?: {
    buildCost: number;
    resourceUsage: {
      cpu: number;
      memory: number;
      duration: number;
    };
  };
  duration?: number;
  startedAt: string;
  completedAt?: string;
}

export interface Deployment {
  id: number;
  buildId: number;
  projectId: number;
  status: 'pending' | 'running' | 'success' | 'failed' | 'cancelled';
  deploymentLogs?: string;
  healthCheckStatus?: string;
  rollbackDeploymentId?: number;
  deployedAt: string;
  completedAt?: string;
}

export interface Agent {
  id: number;
  name: string;
  type: 'autobuild' | 'deploymaster' | 'secureguard' | 'costoptimizer';
  status: 'active' | 'inactive' | 'error';
  configuration?: Record<string, any>;
  lastHeartbeat: string;
  metrics?: {
    tasksCompleted: number;
    averageExecutionTime: number;
    errorRate: number;
  };
}

export interface Notification {
  id: number;
  projectId?: number;
  buildId?: number;
  type: 'success' | 'failure' | 'warning';
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

export interface ProjectStats {
  totalProjects: number;
  activeProjects: number;
  successRate: number;
  avgDeployTime: number;
  monthlyCost: number;
}

export interface SecurityStats {
  criticalVulnerabilities: number;
  highPriorityIssues: number;
  securityScore: string;
}

export interface CostStats {
  monthlySavings: number;
  resourceEfficiency: number;
  recommendations: number;
}

export interface WebSocketMessage {
  type: string;
  data: any;
  timestamp: string;
}

export interface BuildContext {
  commitHash: string;
  branch: string;
  author?: string;
  message?: string;
  isPullRequest?: boolean;
}

export interface DeploymentStrategy {
  type: 'rolling' | 'blue-green' | 'canary';
  parameters: Record<string, any>;
}

export interface ResourceMetrics {
  cpu: number;
  memory: number;
  storage: number;
  network: number;
}

export interface CostOptimizationRecommendation {
  id: string;
  title: string;
  description: string;
  estimatedSavings: number;
  impact: 'low' | 'medium' | 'high';
  category: 'compute' | 'storage' | 'network' | 'services';
}

export interface SecurityVulnerability {
  id: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  title: string;
  description: string;
  solution: string;
  cveId?: string;
  package?: string;
  version?: string;
}

export interface PipelineStage {
  name: string;
  status: 'pending' | 'running' | 'success' | 'failed' | 'skipped';
  duration?: number;
  startTime?: string;
  endTime?: string;
  logs?: string[];
}

export interface BuildArtifact {
  id: string;
  name: string;
  type: 'docker-image' | 'binary' | 'package' | 'report';
  url: string;
  size: number;
  checksum: string;
}
